<?php
// Edit username/password to match your MySQL/MariaDB (XAMPP default: root, no password)
return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=tms_db',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8mb4',
];
