<?php
return ['adminEmail' => 'admin@tms.local'];
