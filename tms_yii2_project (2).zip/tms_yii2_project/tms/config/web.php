<?php
$params = require __DIR__ . '/params.php';
return [
    'id' => 'tms',
    'name' => 'Transport Management System',
    'basePath' => dirname(__DIR__),
    'bootstrap' => ['log'],
    'aliases' => ['@bower' => '@vendor/bower-asset', '@npm' => '@vendor/npm-asset'],
    'timeZone' => 'Africa/Kampala',
    'defaultRoute' => 'site/index',
    'components' => [
        'request' => ['cookieValidationKey' => 'tms-usjm-2026-change-this-secret'],
        'cache' => ['class' => 'yii\caching\FileCache'],
        'user' => [
            'identityClass' => 'app\models\User',
            'enableAutoLogin' => true,
            'loginUrl' => ['site/login'],
        ],
        'errorHandler' => ['errorAction' => 'site/error'],
        'log' => [
            'targets' => [['class' => 'yii\log\FileTarget', 'levels' => ['error', 'warning']]],
        ],
        'db' => require __DIR__ . '/db.php',
    ],
    'params' => $params,
];
