<?php
namespace app\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\filters\VerbFilter;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use app\models\User;
use app\models\Driver;

/** Admin: approve, suspend or reject new accounts (user.approved: 0 = waiting, 1 = approved). */
class ApprovalController extends Controller
{
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::class,
                'rules' => [[
                    'allow' => true,
                    'matchCallback' => function () {
                        return !Yii::$app->user->isGuest && Yii::$app->user->identity->isAdmin();
                    },
                ]],
            ],
            'verbs' => ['class' => VerbFilter::class, 'actions' => [
                'approve' => ['post'], 'suspend' => ['post'], 'reject' => ['post'],
            ]],
        ];
    }

    public function actionIndex()
    {
        $pending = User::find()->where(['approved' => 0])->andWhere(['<>', 'role', 'admin'])->orderBy(['id' => SORT_DESC])->all();
        $approved = User::find()->where(['approved' => 1])->andWhere(['<>', 'role', 'admin'])->orderBy(['id' => SORT_DESC])->limit(10)->all();
        return $this->render('index', compact('pending', 'approved'));
    }

    public function actionApprove($id)
    {
        $u = $this->findUser($id);
        $u->approved = 1;
        $u->save(false, ['approved']);
        Yii::$app->session->setFlash('success', $u->full_name . ' has been approved.');
        return $this->redirect(['index']);
    }

    public function actionSuspend($id)
    {
        $u = $this->findUser($id);
        $u->approved = 0;
        $u->save(false, ['approved']);
        Yii::$app->session->setFlash('warning', $u->full_name . ' is now waiting for approval again.');
        return $this->redirect(['index']);
    }

    public function actionReject($id)
    {
        $u = $this->findUser($id);
        $tx = Yii::$app->db->beginTransaction();
        try {
            $d = Driver::findOne(['user_id' => $u->id]);
            if ($d) {
                $d->delete();
            }
            $u->delete();
            $tx->commit();
            Yii::$app->session->setFlash('success', 'Account rejected and removed.');
        } catch (\Throwable $e) {
            $tx->rollBack();
            Yii::$app->session->setFlash('danger', 'Cannot remove this account because it is already in use. Use Suspend instead.');
        }
        return $this->redirect(['index']);
    }

    private function findUser($id)
    {
        $u = User::findOne($id);
        if (!$u || $u->role === 'admin') {
            throw new NotFoundHttpException('Account not found.');
        }
        return $u;
    }
}
