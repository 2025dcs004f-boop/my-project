<?php
namespace app\controllers;

use Yii;
use yii\data\ActiveDataProvider;
use yii\filters\AccessControl;
use yii\filters\VerbFilter;
use yii\web\Controller;
use yii\web\NotFoundHttpException;

/** Generic admin-only CRUD (list + search/filter, create, update, delete). */
abstract class CrudController extends Controller
{
    abstract protected function modelClass();
    abstract protected function title();

    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::class,
                'rules' => [[
                    'allow' => true,
                    'matchCallback' => function () {
                        return !Yii::$app->user->isGuest && Yii::$app->user->identity->isAdmin();
                    },
                ]],
            ],
            'verbs' => ['class' => VerbFilter::class, 'actions' => ['delete' => ['post']]],
        ];
    }

    public function actionIndex($q = null, $status = null)
    {
        $class = $this->modelClass();
        $model = new $class();
        $query = $class::find();
        if ($q !== null && $q !== '') {
            $or = ['or'];
            foreach ($model->searchAttributes() as $attr) {
                $or[] = ['like', $attr, $q];
            }
            $query->andWhere($or);
        }
        $fa = $model->filterAttribute();
        if ($status && $model->hasAttribute($fa)) {
            $query->andWhere([$fa => $status]);
        }
        $dataProvider = new ActiveDataProvider([
            'query' => $query->orderBy(['id' => SORT_DESC]),
            'pagination' => ['pageSize' => 10],
        ]);
        return $this->render('@app/views/crud/index', [
            'model' => $model, 'dataProvider' => $dataProvider,
            'title' => $this->title(), 'q' => $q, 'status' => $status,
        ]);
    }

    public function actionCreate()
    {
        $class = $this->modelClass();
        $model = new $class();
        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            Yii::$app->session->setFlash('success', 'Record saved successfully.');
            return $this->redirect(['index']);
        }
        return $this->render('@app/views/crud/form', ['model' => $model, 'title' => 'Add ' . $this->title()]);
    }

    public function actionUpdate($id)
    {
        $model = $this->findModel($id);
        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            Yii::$app->session->setFlash('success', 'Record updated successfully.');
            return $this->redirect(['index']);
        }
        return $this->render('@app/views/crud/form', ['model' => $model, 'title' => 'Edit ' . $this->title()]);
    }

    public function actionDelete($id)
    {
        try {
            $this->findModel($id)->delete();
            Yii::$app->session->setFlash('success', 'Record deleted.');
        } catch (\yii\db\IntegrityException $e) {
            Yii::$app->session->setFlash('danger', 'Cannot delete: this record is used by other records.');
        }
        return $this->redirect(['index']);
    }

    protected function findModel($id)
    {
        $class = $this->modelClass();
        if (($model = $class::findOne($id)) === null) {
            throw new NotFoundHttpException('Record not found.');
        }
        return $model;
    }
}
