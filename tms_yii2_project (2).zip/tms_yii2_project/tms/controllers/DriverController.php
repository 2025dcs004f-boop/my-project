<?php
namespace app\controllers;

class DriverController extends CrudController
{
    protected function modelClass() { return 'app\models\\Driver'; }
    protected function title() { return 'Drivers'; }
}
