<?php
namespace app\controllers;

use Yii;
use yii\web\ForbiddenHttpException;
use yii\web\NotFoundHttpException;
use app\models\DriverPayment;

/** Admin: record and manage payments to drivers. Drivers can open their own payslips. */
class DriverPaymentController extends CrudController
{
    protected function modelClass() { return 'app\models\DriverPayment'; }
    protected function title() { return 'Driver Payments'; }

    public function behaviors()
    {
        $b = parent::behaviors();
        $b['access']['rules'] = [
            ['allow' => true, 'actions' => ['payslip'], 'roles' => ['@']],
            ['allow' => true, 'matchCallback' => function () {
                return !Yii::$app->user->isGuest && Yii::$app->user->identity->isAdmin();
            }],
        ];
        return $b;
    }

    public function actionPayslip($id)
    {
        $p = DriverPayment::findOne($id);
        if (!$p) {
            throw new NotFoundHttpException('Payslip not found.');
        }
        $own = $p->driver && $p->driver->user_id == Yii::$app->user->id;
        if (!$own && !Yii::$app->user->identity->isAdmin()) {
            throw new ForbiddenHttpException('You cannot view this payslip.');
        }
        return $this->render('payslip', ['p' => $p]);
    }
}
