<?php
namespace app\controllers;

use Yii;

class MemberController extends CrudController
{
    protected function modelClass() { return 'app\models\Member'; }
    protected function title() { return 'Members'; }

    public function actionDelete($id)
    {
        if ($id == Yii::$app->user->id) {
            Yii::$app->session->setFlash('danger', 'You cannot delete your own account.');
            return $this->redirect(['index']);
        }
        return parent::actionDelete($id);
    }
}
