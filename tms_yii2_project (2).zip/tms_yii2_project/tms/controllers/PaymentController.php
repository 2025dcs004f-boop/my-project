<?php
namespace app\controllers;

use Yii;
use yii\data\ActiveDataProvider;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\web\ForbiddenHttpException;
use yii\web\NotFoundHttpException;
use app\models\Payment;
use app\models\Trip;

class PaymentController extends Controller
{
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::class,
                'rules' => [
                    ['allow' => true, 'actions' => ['index'], 'matchCallback' => function () {
                        return !Yii::$app->user->isGuest && Yii::$app->user->identity->isAdmin();
                    }],
                    ['allow' => true, 'actions' => ['pay', 'my', 'receipt'], 'roles' => ['@']],
                ],
            ],
        ];
    }

    /** Payment page: passenger books seats on a trip and pays */
    public function actionPay($trip_id)
    {
        $trip = Trip::findOne($trip_id);
        if (!$trip || $trip->status !== 'Scheduled') {
            throw new NotFoundHttpException('This trip is not open for booking.');
        }
        $model = new Payment();
        $model->trip_id = $trip->id;
        $model->seats = 1;
        $model->user_id = Yii::$app->user->id;
        if ($model->load(Yii::$app->request->post())) {
            $model->trip_id = $trip->id;
            $model->user_id = Yii::$app->user->id;
            if ($model->save()) {
                Yii::$app->session->setFlash('success', 'Payment successful. Your receipt is below.');
                return $this->redirect(['receipt', 'id' => $model->id]);
            }
        }
        return $this->render('pay', ['model' => $model, 'trip' => $trip]);
    }

    /** Payments of the logged-in passenger */
    public function actionMy()
    {
        $dp = new ActiveDataProvider([
            'query' => Payment::find()->where(['user_id' => Yii::$app->user->id])->with('trip.route')->orderBy(['id' => SORT_DESC]),
            'pagination' => ['pageSize' => 10],
        ]);
        return $this->render('my', ['dataProvider' => $dp]);
    }

    /** Admin: all payments with search */
    public function actionIndex($q = null)
    {
        $query = Payment::find()->joinWith(['user', 'trip.route'])->orderBy(['payment.id' => SORT_DESC]);
        if ($q) {
            $query->andWhere(['or', ['like', 'payment.reference', $q], ['like', 'user.full_name', $q], ['like', 'payment.method', $q]]);
        }
        $dp = new ActiveDataProvider(['query' => $query, 'pagination' => ['pageSize' => 15]]);
        return $this->render('index', ['dataProvider' => $dp, 'q' => $q]);
    }

    /** Printable receipt */
    public function actionReceipt($id)
    {
        $payment = Payment::findOne($id);
        if (!$payment) {
            throw new NotFoundHttpException('Receipt not found.');
        }
        if ($payment->user_id != Yii::$app->user->id && !Yii::$app->user->identity->isAdmin()) {
            throw new ForbiddenHttpException('You cannot view this receipt.');
        }
        return $this->render('receipt', ['payment' => $payment]);
    }
}
