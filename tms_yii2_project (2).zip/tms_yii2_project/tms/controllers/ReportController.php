<?php
namespace app\controllers;

use Yii;
use yii\db\Query;
use yii\filters\AccessControl;
use yii\web\Controller;
use app\models\Payment;
use app\models\DriverPayment;

class ReportController extends Controller
{
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::class,
                'rules' => [[
                    'allow' => true,
                    'matchCallback' => function () {
                        return !Yii::$app->user->isGuest && Yii::$app->user->identity->isAdmin();
                    },
                ]],
            ],
        ];
    }

    /** Monthly report; $month is "YYYY-MM". Print with the Print button (browser print / Save as PDF). */
    public function actionMonthly($month = null)
    {
        if (!$month || !preg_match('/^\d{4}-(0[1-9]|1[0-2])$/', $month)) {
            $month = date('Y-m');
        }
        $start = $month . '-01 00:00:00';
        $end = date('Y-m-d H:i:s', strtotime($start . ' +1 month'));

        $tripStatus = (new Query())->select(['status', 'total' => 'COUNT(*)'])->from('trip')
            ->where(['>=', 'departure_time', $start])->andWhere(['<', 'departure_time', $end])
            ->groupBy('status')->all();

        $summary = (new Query())->select(['payments' => 'COUNT(*)', 'seats' => 'COALESCE(SUM(seats),0)', 'revenue' => 'COALESCE(SUM(amount),0)'])
            ->from('payment')->where(['>=', 'paid_at', $start])->andWhere(['<', 'paid_at', $end])->one();

        $byRoute = (new Query())
            ->select(['r.origin', 'r.destination', 'trips' => 'COUNT(DISTINCT t.id)', 'seats' => 'SUM(p.seats)', 'revenue' => 'SUM(p.amount)'])
            ->from(['p' => 'payment'])->innerJoin(['t' => 'trip'], 't.id = p.trip_id')->innerJoin(['r' => 'route'], 'r.id = t.route_id')
            ->where(['>=', 'p.paid_at', $start])->andWhere(['<', 'p.paid_at', $end])
            ->groupBy('r.id')->orderBy(['revenue' => SORT_DESC])->all();

        $byVehicle = (new Query())->select(['v.plate_number', 'v.type', 'trips' => 'COUNT(t.id)'])
            ->from(['t' => 'trip'])->innerJoin(['v' => 'vehicle'], 'v.id = t.vehicle_id')
            ->where(['>=', 't.departure_time', $start])->andWhere(['<', 't.departure_time', $end])
            ->andWhere(['<>', 't.status', 'Cancelled'])->groupBy('v.id')->orderBy(['trips' => SORT_DESC])->all();

        $byDriver = (new Query())->select(['d.id', 'd.full_name', 'd.license_number', 'trips' => 'COUNT(t.id)'])
            ->from(['t' => 'trip'])->innerJoin(['d' => 'driver'], 'd.id = t.driver_id')
            ->where(['>=', 't.departure_time', $start])->andWhere(['<', 't.departure_time', $end])
            ->andWhere(['<>', 't.status', 'Cancelled'])->groupBy('d.id')->orderBy(['trips' => SORT_DESC])->all();

        $payments = Payment::find()->with(['user', 'trip.route'])
            ->where(['>=', 'paid_at', $start])->andWhere(['<', 'paid_at', $end])->orderBy(['paid_at' => SORT_ASC])->all();

        $driverPays = DriverPayment::find()->with('driver')->where(['period_month' => $month])->orderBy(['paid_at' => SORT_ASC])->all();
        $paidBy = [];
        $driverTotal = 0;
        foreach ($driverPays as $dp) {
            $paidBy[$dp->driver_id] = ($paidBy[$dp->driver_id] ?? 0) + $dp->amount;
            $driverTotal += $dp->amount;
        }
        $net = $summary['revenue'] - $driverTotal;

        return $this->render('monthly', compact('month', 'tripStatus', 'summary', 'byRoute', 'byVehicle', 'byDriver', 'payments',
            'driverPays', 'paidBy', 'driverTotal', 'net'));
    }
}
