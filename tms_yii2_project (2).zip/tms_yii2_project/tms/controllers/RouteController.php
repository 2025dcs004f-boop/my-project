<?php
namespace app\controllers;

class RouteController extends CrudController
{
    protected function modelClass() { return 'app\models\\Route'; }
    protected function title() { return 'Routes'; }
}
