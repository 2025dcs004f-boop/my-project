<?php
namespace app\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\filters\VerbFilter;
use yii\web\Controller;
use app\models\LoginForm;
use app\models\RegisterForm;
use app\models\Trip;
use app\models\Vehicle;
use app\models\Driver;
use app\models\Route;
use app\models\User;
use app\models\Payment;
use app\models\DriverPayment;

class SiteController extends Controller
{
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::class,
                'only' => ['dashboard', 'logout'],
                'rules' => [['allow' => true, 'roles' => ['@']]],
            ],
            'verbs' => ['class' => VerbFilter::class, 'actions' => ['logout' => ['post']]],
        ];
    }

    public function actions()
    {
        return ['error' => ['class' => 'yii\web\ErrorAction']];
    }

    /** Entry page */
    public function actionIndex()
    {
        if (!Yii::$app->user->isGuest) {
            return $this->redirect(['dashboard']);
        }
        return $this->render('index');
    }

    public function actionLogin()
    {
        if (!Yii::$app->user->isGuest) {
            return $this->redirect(['dashboard']);
        }
        $model = new LoginForm();
        if ($model->load(Yii::$app->request->post()) && $model->login()) {
            return $this->redirect(['dashboard']);
        }
        $model->password = '';
        return $this->render('login', ['model' => $model]);
    }

    public function actionRegister()
    {
        $model = new RegisterForm();
        if ($model->load(Yii::$app->request->post()) && $model->register()) {
            Yii::$app->session->setFlash('success', 'Account created. Please log in.');
            return $this->redirect(['login']);
        }
        return $this->render('register', ['model' => $model]);
    }

    public function actionLogout()
    {
        Yii::$app->user->logout();
        return $this->goHome();
    }

    /** Admin dashboard or passenger dashboard depending on role */
    public function actionDashboard()
    {
        $user = Yii::$app->user->identity;
        if ($user->isAdmin()) {
            $monthStart = date('Y-m-01');
            return $this->render('dashboard_admin', [
                'vehicles' => Vehicle::find()->count(),
                'drivers' => Driver::find()->count(),
                'routes' => Route::find()->count(),
                'trips' => Trip::find()->count(),
                'passengers' => User::find()->where(['role' => User::ROLE_PASSENGER])->count(),
                'revenue' => (float)Payment::find()->where(['>=', 'paid_at', $monthStart])->sum('amount'),
                'recent' => Payment::find()->with(['trip.route', 'user'])->orderBy(['id' => SORT_DESC])->limit(5)->all(),
            ]);
        }
        if ($user->role === User::ROLE_DRIVER) {
            $driver = Driver::findOne(['user_id' => $user->id]);
            return $this->render('dashboard_driver', [
                'driver' => $driver,
                'trips' => $driver ? Trip::find()->with(['route', 'vehicle'])->where(['driver_id' => $driver->id])
                    ->andWhere(['<>', 'status', 'Cancelled'])->orderBy(['departure_time' => SORT_DESC])->limit(10)->all() : [],
                'pays' => $driver ? DriverPayment::find()->where(['driver_id' => $driver->id])->orderBy(['id' => SORT_DESC])->limit(12)->all() : [],
                'total' => $driver ? (float)DriverPayment::find()->where(['driver_id' => $driver->id])->sum('amount') : 0,
            ]);
        }
        return $this->render('dashboard_passenger', [
            'trips' => $this->upcomingTrips(),
            'myPayments' => Payment::find()->where(['user_id' => $user->id])->count(),
        ]);
    }

    /** Public list of upcoming trips */
    public function actionTrips()
    {
        return $this->render('trips', ['trips' => $this->upcomingTrips()]);
    }

    private function upcomingTrips()
    {
        return Trip::find()->with(['route', 'vehicle'])
            ->where(['status' => 'Scheduled'])
            ->andWhere(['>=', 'departure_time', date('Y-m-d H:i:s')])
            ->orderBy(['departure_time' => SORT_ASC])->all();
    }
}
