<?php
namespace app\controllers;

class TripController extends CrudController
{
    protected function modelClass() { return 'app\models\\Trip'; }
    protected function title() { return 'Trips'; }
}
