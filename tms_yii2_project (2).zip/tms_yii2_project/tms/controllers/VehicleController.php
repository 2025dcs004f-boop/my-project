<?php
namespace app\controllers;

class VehicleController extends CrudController
{
    protected function modelClass() { return 'app\models\\Vehicle'; }
    protected function title() { return 'Vehicles'; }
}
