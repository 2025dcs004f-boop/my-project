-- Transport Management System - database export (MySQL / MariaDB)
-- Import with phpMyAdmin, or: mysql -u root < database/tms_db.sql
-- Sample login:  admin / password   and   passenger1 / password   (change after first login)

CREATE DATABASE IF NOT EXISTS tms_db CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE tms_db;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS driver_payment, payment, trip, route, driver, vehicle, `user`, migration;
SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE `user` (
  id INT AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(100) NOT NULL,
  username VARCHAR(50) NOT NULL UNIQUE,
  email VARCHAR(100) NOT NULL UNIQUE,
  phone VARCHAR(20),
  password_hash VARCHAR(255) NOT NULL,
  auth_key VARCHAR(32) NOT NULL,
  role ENUM('admin','passenger','driver') NOT NULL DEFAULT 'passenger',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE vehicle (
  id INT AUTO_INCREMENT PRIMARY KEY,
  plate_number VARCHAR(15) NOT NULL UNIQUE,
  type VARCHAR(20) NOT NULL,
  make_model VARCHAR(100),
  capacity INT NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'Available'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE driver (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NULL UNIQUE,
  full_name VARCHAR(100) NOT NULL,
  license_number VARCHAR(30) NOT NULL UNIQUE,
  phone VARCHAR(20) NOT NULL,
  license_expiry DATE NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'Active',
  CONSTRAINT fk_driver_user FOREIGN KEY (user_id) REFERENCES `user`(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE route (
  id INT AUTO_INCREMENT PRIMARY KEY,
  origin VARCHAR(80) NOT NULL,
  destination VARCHAR(80) NOT NULL,
  distance_km DECIMAL(8,2) NOT NULL,
  base_fare DECIMAL(12,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE trip (
  id INT AUTO_INCREMENT PRIMARY KEY,
  route_id INT NOT NULL,
  vehicle_id INT NOT NULL,
  driver_id INT NOT NULL,
  departure_time DATETIME NOT NULL,
  arrival_time DATETIME NULL,
  fare DECIMAL(12,2) NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'Scheduled',
  CONSTRAINT fk_trip_route FOREIGN KEY (route_id) REFERENCES route(id),
  CONSTRAINT fk_trip_vehicle FOREIGN KEY (vehicle_id) REFERENCES vehicle(id),
  CONSTRAINT fk_trip_driver FOREIGN KEY (driver_id) REFERENCES driver(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE payment (
  id INT AUTO_INCREMENT PRIMARY KEY,
  trip_id INT NOT NULL,
  user_id INT NOT NULL,
  seats INT NOT NULL DEFAULT 1,
  amount DECIMAL(12,2) NOT NULL,
  method VARCHAR(20) NOT NULL,
  payer_phone VARCHAR(20),
  reference VARCHAR(30) NOT NULL UNIQUE,
  status VARCHAR(20) NOT NULL DEFAULT 'Paid',
  paid_at DATETIME NOT NULL,
  CONSTRAINT fk_payment_trip FOREIGN KEY (trip_id) REFERENCES trip(id),
  CONSTRAINT fk_payment_user FOREIGN KEY (user_id) REFERENCES `user`(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------- Sample data (password for both users: "password") ----------
INSERT INTO `user` (id, full_name, username, email, phone, password_hash, auth_key, role) VALUES
(1,'System Administrator','admin','admin@tms.local','0700000000','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','adminauthkey0000000000000000000a','admin'),
(2,'Aisha Namukasa','passenger1','aisha@example.com','0772123456','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','passauthkey0000000000000000000b','passenger'),
(3,'John Tumwine','passenger2','john@example.com','0753987654','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','passauthkey0000000000000000000c','passenger');

INSERT INTO vehicle (id, plate_number, type, make_model, capacity, status) VALUES
(1,'UBA 123A','Bus','Scania Marcopolo',60,'Available'),
(2,'UBB 456B','Minibus','Toyota Hiace',14,'Available'),
(3,'UBC 789C','Bus','Yutong ZK6122',54,'Maintenance');

INSERT INTO driver (id, full_name, license_number, phone, license_expiry, status) VALUES
(1,'Peter Mugisha','DL-2020-001','0701111222','2028-05-30','Active'),
(2,'Grace Atuhaire','DL-2021-014','0782333444','2027-11-15','Active'),
(3,'Samuel Okello','DL-2019-077','0759555666','2026-12-01','On Leave');

INSERT INTO route (id, origin, destination, distance_km, base_fare) VALUES
(1,'Mbarara','Kampala',270,25000),
(2,'Mbarara','Kabale',140,15000),
(3,'Kampala','Masaka',130,12000);

INSERT INTO trip (id, route_id, vehicle_id, driver_id, departure_time, arrival_time, fare, status) VALUES
(1,1,1,1,'2026-10-05 07:00:00','2026-10-05 11:30:00',25000,'Completed'),
(2,2,2,2,'2026-10-12 09:00:00','2026-10-12 11:45:00',15000,'Completed'),
(3,3,1,1,'2026-10-20 08:00:00','2026-10-20 10:30:00',12000,'Completed'),
(4,1,1,1,'2026-11-05 07:00:00',NULL,25000,'Scheduled'),
(5,2,2,2,'2026-11-08 09:30:00',NULL,15000,'Scheduled');

INSERT INTO payment (trip_id, user_id, seats, amount, method, payer_phone, reference, status, paid_at) VALUES
(1,2,2,50000,'Mobile Money','0772123456','TMS261001AAAAAA','Paid','2026-10-01 10:15:00'),
(1,3,1,25000,'Cash',NULL,'TMS261002BBBBBB','Paid','2026-10-02 14:20:00'),
(2,2,3,45000,'Card',NULL,'TMS261008CCCCCC','Paid','2026-10-08 09:05:00'),
(3,3,4,48000,'Mobile Money','0753987654','TMS261015DDDDDD','Paid','2026-10-15 16:40:00'),
(4,2,2,50000,'Mobile Money','0772123456','TMS261029EEEEEE','Paid','2026-10-29 11:00:00');

-- ---------- Driver payments ----------
CREATE TABLE driver_payment (
  id INT AUTO_INCREMENT PRIMARY KEY,
  driver_id INT NOT NULL,
  type VARCHAR(20) NOT NULL DEFAULT 'Salary',
  period_month CHAR(7) NOT NULL,
  amount DECIMAL(12,2) NOT NULL,
  method VARCHAR(20) NOT NULL,
  reference VARCHAR(30) NOT NULL UNIQUE,
  note VARCHAR(255) NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'Paid',
  paid_by INT NULL,
  paid_at DATETIME NOT NULL,
  UNIQUE KEY uq_driver_month_type (driver_id, period_month, type),
  CONSTRAINT fk_dp_driver FOREIGN KEY (driver_id) REFERENCES driver(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO driver_payment (driver_id, type, period_month, amount, method, reference, note, status, paid_by, paid_at) VALUES
(1,'Salary','2026-10',600000,'Bank Transfer','DP261031AAAAAA','October salary','Paid',1,'2026-10-31 16:00:00'),
(2,'Salary','2026-10',550000,'Mobile Money','DP261031BBBBBB','October salary','Paid',1,'2026-10-31 16:05:00'),
(1,'Bonus','2026-10',50000,'Cash','DP261031CCCCCC','Punctuality bonus','Paid',1,'2026-10-31 16:10:00');
