-- Run ONCE on your existing tms_db (adds driver accounts + driver payments)
USE tms_db;

ALTER TABLE `user` MODIFY role ENUM('admin','passenger','driver') NOT NULL DEFAULT 'passenger';

ALTER TABLE driver ADD COLUMN user_id INT NULL UNIQUE AFTER id;
ALTER TABLE driver ADD CONSTRAINT fk_driver_user FOREIGN KEY (user_id) REFERENCES `user`(id) ON DELETE SET NULL;

CREATE TABLE driver_payment (
  id INT AUTO_INCREMENT PRIMARY KEY,
  driver_id INT NOT NULL,
  type VARCHAR(20) NOT NULL DEFAULT 'Salary',
  period_month CHAR(7) NOT NULL,
  amount DECIMAL(12,2) NOT NULL,
  method VARCHAR(20) NOT NULL,
  reference VARCHAR(30) NOT NULL UNIQUE,
  note VARCHAR(255) NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'Paid',
  paid_by INT NULL,
  paid_at DATETIME NOT NULL,
  UNIQUE KEY uq_driver_month_type (driver_id, period_month, type),
  CONSTRAINT fk_dp_driver FOREIGN KEY (driver_id) REFERENCES driver(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO driver_payment (driver_id, type, period_month, amount, method, reference, note, status, paid_by, paid_at) VALUES
(1,'Salary','2026-10',600000,'Bank Transfer','DP261031AAAAAA','October salary','Paid',1,'2026-10-31 16:00:00'),
(2,'Salary','2026-10',550000,'Mobile Money','DP261031BBBBBB','October salary','Paid',1,'2026-10-31 16:05:00'),
(1,'Bonus','2026-10',50000,'Cash','DP261031CCCCCC','Punctuality bonus','Paid',1,'2026-10-31 16:10:00');
