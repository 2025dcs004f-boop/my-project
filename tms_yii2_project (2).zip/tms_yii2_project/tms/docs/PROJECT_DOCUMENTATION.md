---
title: "Transport Management System (TMS)"
subtitle: "Mid-Semester One Examination 2026/2027 — Diploma in Computer Science, USJM"
---

**Student Name:** ______________________  **Registration No.:** ______________________
**Assigned PHP Framework:** Yii 2 (Basic application)

# Question 1: Problem Identification and Project Proposal

## 1.1 Project Title
**Design and Implementation of a Web-Based Transport Management System for Managing Vehicles, Drivers, Routes, Trips and Passenger Payments Using Yii 2.**

## 1.2 Background
Many small and medium transport companies in Uganda (bus and minibus operators) still record vehicles, drivers, trips and passenger payments in paper books or scattered spreadsheets. Details such as which vehicle is assigned to which driver, how many seats are left on a trip, or how much money a route earned in a month must be calculated by hand. This is slow, error-prone and makes accountability and planning difficult for management.

## 1.3 Problem Statement
Transport operators lack a central, reliable system for recording fleet, driver, route and trip information and for collecting and tracking passenger payments. As a result, trips are poorly scheduled, seats may be double-booked, payment records get lost, and managers cannot quickly produce accurate monthly reports.

## 1.4 Main Objective
To develop a web-based Transport Management System that automates the management of vehicles, drivers, routes, trips and payments and produces printable monthly reports.

## 1.5 Specific Objectives
1. To create a secure registration and login module for administrators and passengers.
2. To manage (add, view, edit, delete, search) vehicles, drivers, routes and trips.
3. To allow passengers to book seats on scheduled trips and record their payments with printable receipts.
4. To generate a monthly report (trips, revenue per route, vehicle and driver activity) that the administrator can print.

## 1.6 Target Users and Expected Benefits
| User | Benefit |
|---|---|
| Administrator / manager | Central control of fleet, drivers, routes, trips; instant monthly reports; less paperwork and fewer errors |
| Passengers | See available trips and fares, book seats, pay and receive a receipt without queueing |
| Transport company | Better accountability for revenue, better vehicle and driver utilisation |

# Question 2: Requirements Analysis

## 2.1 Functional Requirements
- FR1: The system shall allow a passenger to register an account (validated input, hashed password).
- FR2: The system shall authenticate users (login/logout) and restrict pages by role (admin / passenger).
- FR3: The admin shall add, view, update, delete and search/filter vehicles.
- FR4: The admin shall add, view, update, delete and search/filter drivers.
- FR5: The admin shall add, view, update, delete and search routes.
- FR6: The admin shall schedule trips by assigning a route, vehicle and driver, and manage trip status.
- FR7: A passenger shall view upcoming trips, book seats and make a payment (Mobile Money, Card or Cash); the system shall prevent over-booking.
- FR8: The system shall generate a printable payment receipt.
- FR9: The admin shall generate a monthly report and print it (or save as PDF).
- FR10: The admin dashboard shall show summary statistics and recent payments.

## 2.2 Non-Functional Requirements
- NFR1 **Security:** passwords hashed (bcrypt), CSRF protection, role-based access control, SQL-injection-safe queries (Active Record), output encoding.
- NFR2 **Usability:** responsive Bootstrap interface that works on phones and desktops.
- NFR3 **Reliability/Integrity:** foreign keys and validation keep data consistent.
- NFR4 **Performance:** pages load in under 3 seconds for normal data volumes (paginated lists).
- NFR5 **Maintainability:** MVC structure, one reusable CRUD controller/view set.

## 2.3 Actors and Activities
| Actor | Major activities |
|---|---|
| Administrator | Login; manage vehicles, drivers, routes, trips; view all payments; generate and print monthly report |
| Passenger | Register; login; view trips; book and pay; view payment history; print receipt |
| Guest | View entry page and upcoming trips; register or login |

# Question 3: System and Database Design

## 3.1 High-Level Architecture
The system is a three-tier web application following MVC: browser (presentation), Yii 2 PHP application (logic), MySQL/MariaDB (data).

![System architecture](architecture.png)

## 3.2 Entity Relationship Diagram
![ERD](erd.png)

Relationships: a route, a vehicle and a driver can each be used on many trips; a trip can have many payments; a user (passenger) can make many payments.

## 3.3 Database Tables
| Table | Major attributes | Keys |
|---|---|---|
| user | id, full_name, username, email, phone, password_hash, auth_key, role, created_at | PK id; UQ username, email |
| vehicle | id, plate_number, type, make_model, capacity, status | PK id; UQ plate_number |
| driver | id, full_name, license_number, phone, license_expiry, status | PK id; UQ license_number |
| route | id, origin, destination, distance_km, base_fare | PK id |
| trip | id, route_id, vehicle_id, driver_id, departure_time, arrival_time, fare, status | PK id; FK route_id, vehicle_id, driver_id |
| payment | id, trip_id, user_id, seats, amount, method, payer_phone, reference, status, paid_at | PK id; FK trip_id, user_id; UQ reference |

## 3.4 Navigation Structure
```
Guest:      Home -> Login | Register | Trips
Passenger:  Dashboard -> Trips -> Book & Pay -> Receipt ; My Payments ; Logout
Admin:      Dashboard -> Vehicles | Drivers | Routes | Manage Trips | Payments | Monthly Report (Print) ; Logout
```

# Question 4: Assigned Framework and MVC Implementation

| Requirement | Implementation in this project |
|---|---|
| Install/configure Yii 2 | `composer install`; configuration in `config/web.php`, `config/db.php` |
| Route | Yii routes `?r=controller/action`, e.g. `?r=site/login`, `?r=report/monthly` |
| Controller | `controllers/SiteController.php`, `VehicleController.php`, `PaymentController.php`, `ReportController.php` … |
| Model | `models/User.php`, `Vehicle.php`, `Trip.php`, `Payment.php` (Active Record) |
| View | `views/site/login.php`, `views/crud/index.php`, `views/report/monthly.php` … |
| MySQL connection | `config/db.php` (`yii\db\Connection`) |

**How Yii 2 supports MVC.** The request enters `web/index.php`, and Yii's router maps the URL to a controller action. The **controller** handles the request and validation flow; the **model** (Active Record) represents a database table, defines validation rules and relations (e.g. `Trip::getRoute()`); the **view** is a PHP template that displays the data inside the shared layout `views/layouts/main.php`. This separates logic, data and presentation, which makes the code easier to maintain.

# Question 5: Initial Functional Prototype

| Requirement | Where |
|---|---|
| Entry/login page | `?r=site/index`, `?r=site/login`, `?r=site/register` |
| Dashboard | `?r=site/dashboard` (admin and passenger versions) |
| At least two forms | Register, Login, Vehicle/Driver/Route/Trip forms, Payment form |
| Database connectivity | Active Record via `config/db.php` |
| INSERT | Register user, add vehicle/driver/route/trip, make payment |
| SELECT | Lists with search/filter, dashboard, reports |
| Navigation | Navbar in `views/layouts/main.php` |
| Printable monthly report | `?r=report/monthly` → "Print / Save as PDF" button |

# Testing Summary
| # | Test | Expected | Result |
|---|---|---|---|
| 1 | Register with mismatched passwords | Validation error | ☐ Pass |
| 2 | Login with wrong password | Error message | ☐ Pass |
| 3 | Passenger opens `?r=vehicle/index` | Access denied (403) | ☐ Pass |
| 4 | Admin adds vehicle with duplicate plate | Validation error | ☐ Pass |
| 5 | Admin schedules a trip | Saved and listed | ☐ Pass |
| 6 | Passenger books more seats than available | Error | ☐ Pass |
| 7 | Passenger pays for seats | Receipt generated | ☐ Pass |
| 8 | Admin generates monthly report and prints | Totals match payments | ☐ Pass |

# Mid-Semester Submission Checklist
- [x] Project proposal, requirements, design/ERD (this document)
- [x] Initial source code (`tms/` folder), SQL export (`database/tms_db.sql`), README
- [ ] Screenshots of the working prototype (insert below after running the system)
