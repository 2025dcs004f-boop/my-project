<?php
namespace app\models;

use yii\db\ActiveRecord;

/** Base class used by the generic admin CRUD screens. */
abstract class BaseModel extends ActiveRecord
{
    /** Form fields: attribute => ['type' => text|number|date|datetime|textarea|dropdown, 'items' => [...]] */
    abstract public function formFields();

    /** GridView columns shown on the list page. */
    abstract public function listColumns();

    /** Attributes searched by the search box. */
    public function searchAttributes()
    {
        return [];
    }

    /** Column used by the filter dropdown. */
    public function filterAttribute()
    {
        return 'status';
    }

    /** Values for the status filter (empty = no filter). */
    public static function statusOptions()
    {
        return [];
    }

    protected static function opts(array $list)
    {
        return array_combine($list, $list);
    }
}
