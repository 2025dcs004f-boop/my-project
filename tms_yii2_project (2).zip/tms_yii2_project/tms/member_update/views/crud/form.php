<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;
/** @var $model app\models\BaseModel */
$this->title = $title;
?>
<div class="row justify-content-center"><div class="col-md-7"><div class="card stat-card"><div class="card-body p-4">
<h3 class="mb-3"><?= Html::encode($title) ?></h3>
<?php $form = ActiveForm::begin(); ?>
<?php foreach ($model->formFields() as $attr => $cfg):
    $f = $form->field($model, $attr);
    switch ($cfg['type']) {
        case 'dropdown': echo $f->dropDownList($cfg['items'], ['prompt' => '-- Select --', 'class' => 'form-select']); break;
        case 'password': echo $f->passwordInput(['value' => '', 'autocomplete' => 'new-password']); break;
        case 'textarea': echo $f->textarea(['rows' => 3]); break;
        case 'number':   echo $f->input('number', ['step' => 'any']); break;
        case 'date':     echo $f->input('date'); break;
        case 'datetime':
            $v = $model->$attr ? date('Y-m-d\TH:i', strtotime($model->$attr)) : null;
            echo $f->input('datetime-local', ['value' => $v]); break;
        default:         echo $f->textInput();
    }
endforeach; ?>
<?= Html::submitButton('Save', ['class' => 'btn btn-primary']) ?>
<?= Html::a('Cancel', ['index'], ['class' => 'btn btn-link']) ?>
<?php ActiveForm::end(); ?>
</div></div></div></div>
