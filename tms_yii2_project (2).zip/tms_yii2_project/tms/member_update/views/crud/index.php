<?php
use yii\helpers\Html;
use yii\grid\GridView;
/** @var $model app\models\BaseModel */
$this->title = $title;
$statuses = $model::statusOptions();
?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h3 class="mb-0"><?= Html::encode($title) ?></h3>
    <?= Html::a('+ Add new', ['create'], ['class' => 'btn btn-primary']) ?>
</div>
<form method="get" class="row g-2 mb-3">
    <input type="hidden" name="r" value="<?= Html::encode($this->context->id . '/index') ?>">
    <?php if ($model->searchAttributes()): ?>
    <div class="col-md-5"><input type="text" name="q" value="<?= Html::encode($q) ?>" class="form-control" placeholder="Search..."></div>
    <?php endif; ?>
    <?php if ($statuses): ?>
    <div class="col-md-3"><?= Html::dropDownList('status', $status, $statuses, ['prompt' => 'All', 'class' => 'form-select']) ?></div>
    <?php endif; ?>
    <div class="col-auto"><button class="btn btn-outline-secondary">Filter</button>
        <?= Html::a('Reset', ['index'], ['class' => 'btn btn-link']) ?></div>
</form>
<div class="card stat-card"><div class="card-body">
<?= GridView::widget([
    'dataProvider' => $dataProvider,
    'tableOptions' => ['class' => 'table table-striped align-middle'],
    'layout' => "{items}\n{summary}\n{pager}",
    'pager' => ['linkContainerOptions' => ['class' => 'page-item'], 'linkOptions' => ['class' => 'page-link'],
        'disabledListItemSubTagOptions' => ['class' => 'page-link'], 'options' => ['class' => 'pagination']],
    'columns' => array_merge($model->listColumns(), [[
        'class' => 'yii\grid\ActionColumn',
        'template' => '{update} {delete}',
        'buttons' => [
            'update' => function ($url) { return Html::a('Edit', $url, ['class' => 'btn btn-sm btn-outline-primary']); },
            'delete' => function ($url) {
                return Html::a('Delete', $url, ['class' => 'btn btn-sm btn-outline-danger',
                    'data' => ['method' => 'post', 'confirm' => 'Delete this record?']]);
            },
        ],
    ]]),
]) ?>
</div></div>
