<?php
use yii\db\Migration;

/** Creates all TMS tables and the default admin account. Run: php yii migrate */
class m261031_000000_create_tms_tables extends Migration
{
    public function safeUp()
    {
        $opt = 'ENGINE=InnoDB DEFAULT CHARSET=utf8mb4';

        $this->createTable('user', [
            'id' => $this->primaryKey(),
            'full_name' => $this->string(100)->notNull(),
            'username' => $this->string(50)->notNull()->unique(),
            'email' => $this->string(100)->notNull()->unique(),
            'phone' => $this->string(20),
            'password_hash' => $this->string(255)->notNull(),
            'auth_key' => $this->string(32)->notNull(),
            'role' => "ENUM('admin','passenger') NOT NULL DEFAULT 'passenger'",
            'created_at' => $this->timestamp()->defaultExpression('CURRENT_TIMESTAMP'),
        ], $opt);

        $this->createTable('vehicle', [
            'id' => $this->primaryKey(),
            'plate_number' => $this->string(15)->notNull()->unique(),
            'type' => $this->string(20)->notNull(),
            'make_model' => $this->string(100),
            'capacity' => $this->integer()->notNull(),
            'status' => $this->string(20)->notNull()->defaultValue('Available'),
        ], $opt);

        $this->createTable('driver', [
            'id' => $this->primaryKey(),
            'full_name' => $this->string(100)->notNull(),
            'license_number' => $this->string(30)->notNull()->unique(),
            'phone' => $this->string(20)->notNull(),
            'license_expiry' => $this->date()->notNull(),
            'status' => $this->string(20)->notNull()->defaultValue('Active'),
        ], $opt);

        $this->createTable('route', [
            'id' => $this->primaryKey(),
            'origin' => $this->string(80)->notNull(),
            'destination' => $this->string(80)->notNull(),
            'distance_km' => $this->decimal(8, 2)->notNull(),
            'base_fare' => $this->decimal(12, 2)->notNull(),
        ], $opt);

        $this->createTable('trip', [
            'id' => $this->primaryKey(),
            'route_id' => $this->integer()->notNull(),
            'vehicle_id' => $this->integer()->notNull(),
            'driver_id' => $this->integer()->notNull(),
            'departure_time' => $this->dateTime()->notNull(),
            'arrival_time' => $this->dateTime(),
            'fare' => $this->decimal(12, 2)->notNull(),
            'status' => $this->string(20)->notNull()->defaultValue('Scheduled'),
        ], $opt);
        $this->addForeignKey('fk_trip_route', 'trip', 'route_id', 'route', 'id', 'RESTRICT');
        $this->addForeignKey('fk_trip_vehicle', 'trip', 'vehicle_id', 'vehicle', 'id', 'RESTRICT');
        $this->addForeignKey('fk_trip_driver', 'trip', 'driver_id', 'driver', 'id', 'RESTRICT');

        $this->createTable('payment', [
            'id' => $this->primaryKey(),
            'trip_id' => $this->integer()->notNull(),
            'user_id' => $this->integer()->notNull(),
            'seats' => $this->integer()->notNull()->defaultValue(1),
            'amount' => $this->decimal(12, 2)->notNull(),
            'method' => $this->string(20)->notNull(),
            'payer_phone' => $this->string(20),
            'reference' => $this->string(30)->notNull()->unique(),
            'status' => $this->string(20)->notNull()->defaultValue('Paid'),
            'paid_at' => $this->dateTime()->notNull(),
        ], $opt);
        $this->addForeignKey('fk_payment_trip', 'payment', 'trip_id', 'trip', 'id', 'RESTRICT');
        $this->addForeignKey('fk_payment_user', 'payment', 'user_id', 'user', 'id', 'RESTRICT');

        // Default admin: username "admin", password "Admin@123" (change after first login)
        $this->insert('user', [
            'full_name' => 'System Administrator', 'username' => 'admin', 'email' => 'admin@tms.local',
            'password_hash' => Yii::$app->security->generatePasswordHash('Admin@123'),
            'auth_key' => Yii::$app->security->generateRandomString(32), 'role' => 'admin',
        ]);
    }

    public function safeDown()
    {
        foreach (['payment', 'trip', 'route', 'driver', 'vehicle', 'user'] as $t) {
            $this->dropTable($t);
        }
    }
}
