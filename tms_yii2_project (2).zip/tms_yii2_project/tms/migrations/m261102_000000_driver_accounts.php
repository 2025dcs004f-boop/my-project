<?php
use yii\db\Migration;

/** Adds the driver role, driver.user_id and the driver_payment table (for installs created with php yii migrate). */
class m261102_000000_driver_accounts extends Migration
{
    public function safeUp()
    {
        $this->execute("ALTER TABLE `user` MODIFY role ENUM('admin','passenger','driver') NOT NULL DEFAULT 'passenger'");
        $this->addColumn('driver', 'user_id', $this->integer()->null()->unique()->after('id'));
        $this->addForeignKey('fk_driver_user', 'driver', 'user_id', 'user', 'id', 'SET NULL');
        $this->createTable('driver_payment', [
            'id' => $this->primaryKey(),
            'driver_id' => $this->integer()->notNull(),
            'type' => $this->string(20)->notNull()->defaultValue('Salary'),
            'period_month' => $this->char(7)->notNull(),
            'amount' => $this->decimal(12, 2)->notNull(),
            'method' => $this->string(20)->notNull(),
            'reference' => $this->string(30)->notNull()->unique(),
            'note' => $this->string(255),
            'status' => $this->string(20)->notNull()->defaultValue('Paid'),
            'paid_by' => $this->integer(),
            'paid_at' => $this->dateTime()->notNull(),
        ], 'ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
        $this->createIndex('uq_driver_month_type', 'driver_payment', ['driver_id', 'period_month', 'type'], true);
        $this->addForeignKey('fk_dp_driver', 'driver_payment', 'driver_id', 'driver', 'id', 'RESTRICT');
    }

    public function safeDown()
    {
        $this->dropTable('driver_payment');
        $this->dropForeignKey('fk_driver_user', 'driver');
        $this->dropColumn('driver', 'user_id');
        $this->execute("ALTER TABLE `user` MODIFY role ENUM('admin','passenger') NOT NULL DEFAULT 'passenger'");
    }
}
