<?php
namespace app\models;

class Driver extends BaseModel
{
    public static function tableName() { return 'driver'; }

    public static function statusOptions() { return self::opts(['Active', 'On Leave', 'Suspended']); }

    public function rules()
    {
        return [
            [['full_name', 'license_number', 'phone', 'license_expiry', 'status'], 'required'],
            ['license_number', 'unique'],
            [['full_name'], 'string', 'max' => 100],
            ['license_number', 'string', 'max' => 30],
            ['phone', 'match', 'pattern' => '/^[0-9+ ]{9,15}$/', 'message' => 'Enter a valid phone number.'],
            ['license_expiry', 'date', 'format' => 'php:Y-m-d'],
            ['status', 'in', 'range' => array_keys(self::statusOptions())],
        ];
    }

    public function getUser() { return $this->hasOne(User::class, ['id' => 'user_id']); }
    public function getPayments() { return $this->hasMany(DriverPayment::class, ['driver_id' => 'id']); }

    public function formFields()
    {
        return [
            'full_name' => ['type' => 'text'],
            'license_number' => ['type' => 'text'],
            'phone' => ['type' => 'text'],
            'license_expiry' => ['type' => 'date'],
            'status' => ['type' => 'dropdown', 'items' => self::statusOptions()],
        ];
    }

    public function listColumns()
    {
        return ['id', 'full_name', 'license_number', 'phone', 'license_expiry', 'status',
            ['label' => 'Login account', 'value' => function ($m) { return $m->user ? $m->user->username : '—'; }]];
    }

    public function searchAttributes() { return ['full_name', 'license_number', 'phone']; }
}
