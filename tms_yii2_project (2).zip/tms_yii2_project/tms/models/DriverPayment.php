<?php
namespace app\models;

use Yii;
use yii\helpers\ArrayHelper;
use yii\helpers\Html;

/** Money paid to a driver (salary, allowance or bonus) for a given month. */
class DriverPayment extends BaseModel
{
    public static function tableName() { return 'driver_payment'; }

    public static function statusOptions() { return self::opts(['Salary', 'Allowance', 'Bonus']); }

    public function filterAttribute() { return 'type'; }

    public static function methods() { return self::opts(['Bank Transfer', 'Mobile Money', 'Cash']); }

    public function rules()
    {
        return [
            [['driver_id', 'type', 'period_month', 'amount', 'method'], 'required'],
            ['driver_id', 'exist', 'targetClass' => Driver::class, 'targetAttribute' => 'id'],
            ['type', 'in', 'range' => array_keys(self::statusOptions())],
            ['period_month', 'match', 'pattern' => '/^\d{4}-(0[1-9]|1[0-2])$/', 'message' => 'Choose a valid month.'],
            ['amount', 'number', 'min' => 1],
            ['method', 'in', 'range' => array_keys(self::methods())],
            ['note', 'string', 'max' => 255],
            ['driver_id', 'unique', 'targetAttribute' => ['driver_id', 'period_month', 'type'],
                'message' => 'This payment type was already recorded for this driver and month.'],
        ];
    }

    public function attributeLabels()
    {
        return ['driver_id' => 'Driver', 'period_month' => 'For month', 'type' => 'Payment type'];
    }

    public function beforeSave($insert)
    {
        if ($insert) {
            $this->status = 'Paid';
            $this->paid_at = date('Y-m-d H:i:s');
            $this->paid_by = Yii::$app->user->id;
            $this->reference = preg_replace('/[^A-Z0-9]/', 'X', 'DP' . date('ymd') . strtoupper(Yii::$app->security->generateRandomString(6)));
        }
        return parent::beforeSave($insert);
    }

    public function getDriver() { return $this->hasOne(Driver::class, ['id' => 'driver_id']); }

    public function formFields()
    {
        return [
            'driver_id' => ['type' => 'dropdown', 'items' => ArrayHelper::map(Driver::find()->orderBy('full_name')->all(), 'id',
                function ($d) { return $d->full_name . ' (' . $d->license_number . ')'; })],
            'type' => ['type' => 'dropdown', 'items' => self::statusOptions()],
            'period_month' => ['type' => 'month'],
            'amount' => ['type' => 'number'],
            'method' => ['type' => 'dropdown', 'items' => self::methods()],
            'note' => ['type' => 'textarea'],
        ];
    }

    public function listColumns()
    {
        return [
            'id',
            ['label' => 'Driver', 'value' => function ($m) { return $m->driver->full_name; }],
            'period_month', 'type',
            ['attribute' => 'amount', 'value' => function ($m) { return number_format($m->amount); }],
            'method', 'reference', 'paid_at',
            ['format' => 'raw', 'label' => '', 'value' => function ($m) {
                return Html::a('Payslip', ['driver-payment/payslip', 'id' => $m->id], ['class' => 'btn btn-sm btn-outline-secondary']);
            }],
        ];
    }

    public function searchAttributes() { return ['reference', 'period_month', 'method', 'note']; }
}
