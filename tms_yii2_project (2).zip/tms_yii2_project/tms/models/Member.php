<?php
namespace app\models;

use Yii;

/** A system member (admin or passenger) managed by the administrator. Uses the `user` table. */
class Member extends BaseModel
{
    public $password;

    public static function tableName() { return 'user'; }

    public static function statusOptions() { return self::opts(['admin', 'passenger', 'driver']); }

    public function filterAttribute() { return 'role'; }

    public function rules()
    {
        return [
            [['full_name', 'username', 'email', 'role'], 'required'],
            ['full_name', 'string', 'max' => 100],
            ['username', 'string', 'min' => 3, 'max' => 50],
            ['username', 'match', 'pattern' => '/^[a-zA-Z0-9_.]+$/', 'message' => 'Letters, numbers, dot and underscore only.'],
            ['email', 'email'],
            [['username', 'email'], 'unique'],
            ['phone', 'match', 'pattern' => '/^[0-9+ ]{9,15}$/', 'message' => 'Enter a valid phone number.'],
            ['role', 'in', 'range' => array_keys(self::statusOptions())],
            ['password', 'required', 'when' => function ($m) { return $m->isNewRecord; }],
            ['password', 'string', 'min' => 6],
        ];
    }

    public function attributeHints()
    {
        return ['password' => 'Minimum 6 characters. When editing, leave blank to keep the current password.'];
    }

    public function beforeSave($insert)
    {
        if ($this->password) {
            $this->password_hash = Yii::$app->security->generatePasswordHash($this->password);
        }
        if ($insert && !$this->auth_key) {
            $this->auth_key = Yii::$app->security->generateRandomString(32);
        }
        return parent::beforeSave($insert);
    }

    public function formFields()
    {
        return [
            'full_name' => ['type' => 'text'],
            'username' => ['type' => 'text'],
            'email' => ['type' => 'text'],
            'phone' => ['type' => 'text'],
            'role' => ['type' => 'dropdown', 'items' => self::statusOptions()],
            'password' => ['type' => 'password'],
        ];
    }

    public function listColumns()
    {
        return ['id', 'full_name', 'username', 'email', 'phone', 'role', 'created_at'];
    }

    public function searchAttributes() { return ['full_name', 'username', 'email', 'phone']; }
}
