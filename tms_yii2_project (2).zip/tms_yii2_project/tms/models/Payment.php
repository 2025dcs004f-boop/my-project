<?php
namespace app\models;

use Yii;
use yii\db\ActiveRecord;

class Payment extends ActiveRecord
{
    public static function tableName() { return 'payment'; }

    public static function methods()
    {
        return ['Mobile Money' => 'Mobile Money', 'Card' => 'Card', 'Cash' => 'Cash'];
    }

    public function rules()
    {
        return [
            [['trip_id', 'seats', 'method'], 'required'],
            ['seats', 'integer', 'min' => 1],
            ['seats', 'validateSeats'],
            ['method', 'in', 'range' => array_keys(self::methods())],
            ['payer_phone', 'match', 'pattern' => '/^[0-9+ ]{9,15}$/', 'message' => 'Enter a valid phone number.'],
            ['payer_phone', 'required', 'when' => function ($m) { return $m->method === 'Mobile Money'; },
                'whenClient' => "function(){return $('#payment-method').val()==='Mobile Money';}"],
        ];
    }

    public function validateSeats($attribute)
    {
        $trip = Trip::findOne($this->trip_id);
        if (!$trip) {
            $this->addError('trip_id', 'Trip not found.');
        } elseif ($this->$attribute > $trip->seatsAvailable) {
            $this->addError($attribute, 'Only ' . $trip->seatsAvailable . ' seat(s) left on this trip.');
        }
    }

    public function beforeSave($insert)
    {
        if ($insert) {
            $trip = Trip::findOne($this->trip_id);
            $this->amount = $trip->fare * $this->seats;
            $this->status = 'Paid';
            $this->paid_at = date('Y-m-d H:i:s');
            $this->reference = 'TMS' . date('ymd') . strtoupper(Yii::$app->security->generateRandomString(6));
            $this->reference = preg_replace('/[^A-Z0-9]/', 'X', $this->reference);
        }
        return parent::beforeSave($insert);
    }

    public function getTrip() { return $this->hasOne(Trip::class, ['id' => 'trip_id']); }
    public function getUser() { return $this->hasOne(User::class, ['id' => 'user_id']); }
}
