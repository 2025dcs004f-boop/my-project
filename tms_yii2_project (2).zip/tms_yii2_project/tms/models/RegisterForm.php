<?php
namespace app\models;

use Yii;
use yii\base\Model;

class RegisterForm extends Model
{
    public $account_type = 'passenger';
    public $full_name;
    public $username;
    public $email;
    public $phone;
    public $password;
    public $password_repeat;
    public $license_number;
    public $license_expiry;

    public function rules()
    {
        $isDriver = function ($m) { return $m->account_type === 'driver'; };
        $isDriverJs = "function(){return $('#registerform-account_type').val()==='driver';}";
        return [
            ['account_type', 'in', 'range' => ['passenger', 'driver']],
            [['full_name', 'username', 'email', 'password', 'password_repeat'], 'required'],
            ['username', 'string', 'min' => 3, 'max' => 50],
            ['username', 'match', 'pattern' => '/^[a-zA-Z0-9_.]+$/', 'message' => 'Letters, numbers, dot and underscore only.'],
            ['email', 'email'],
            [['username', 'email'], 'unique', 'targetClass' => User::class],
            ['phone', 'match', 'pattern' => '/^[0-9+ ]{9,15}$/', 'message' => 'Enter a valid phone number.'],
            ['password', 'string', 'min' => 6],
            ['password_repeat', 'compare', 'compareAttribute' => 'password', 'message' => 'Passwords do not match.'],
            // driver-only fields
            [['phone', 'license_number', 'license_expiry'], 'required', 'when' => $isDriver, 'whenClient' => $isDriverJs],
            ['license_number', 'string', 'max' => 30],
            ['license_number', 'unique', 'targetClass' => Driver::class, 'targetAttribute' => 'license_number',
                'when' => $isDriver, 'whenClient' => $isDriverJs, 'message' => 'This licence number is already registered.'],
            ['license_expiry', 'date', 'format' => 'php:Y-m-d'],
            ['license_expiry', 'compare', 'compareValue' => date('Y-m-d'), 'operator' => '>',
                'when' => $isDriver, 'whenClient' => $isDriverJs, 'message' => 'Your licence must not be expired.'],
        ];
    }

    public function attributeLabels()
    {
        return ['account_type' => 'I am registering as', 'license_number' => 'Driving licence number', 'license_expiry' => 'Licence expiry date'];
    }

    public function register()
    {
        if (!$this->validate()) {
            return null;
        }
        $tx = Yii::$app->db->beginTransaction();
        try {
            $user = new User();
            $user->full_name = $this->full_name;
            $user->username = $this->username;
            $user->email = $this->email;
            $user->phone = $this->phone;
            $user->role = $this->account_type === 'driver' ? User::ROLE_DRIVER : User::ROLE_PASSENGER;
            $user->setPassword($this->password);
            if (!$user->save()) {
                throw new \Exception('Could not save account.');
            }
            if ($this->account_type === 'driver') {
                $d = new Driver();
                $d->user_id = $user->id;
                $d->full_name = $this->full_name;
                $d->license_number = $this->license_number;
                $d->phone = $this->phone;
                $d->license_expiry = $this->license_expiry;
                $d->status = 'Active';
                if (!$d->save()) {
                    throw new \Exception('Could not save driver profile: ' . implode(' ', $d->getFirstErrors()));
                }
            }
            $tx->commit();
            return $user;
        } catch (\Throwable $e) {
            $tx->rollBack();
            $this->addError('username', $e->getMessage());
            return null;
        }
    }
}
