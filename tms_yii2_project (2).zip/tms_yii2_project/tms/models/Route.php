<?php
namespace app\models;

class Route extends BaseModel
{
    public static function tableName() { return 'route'; }

    public function rules()
    {
        return [
            [['origin', 'destination', 'distance_km', 'base_fare'], 'required'],
            [['origin', 'destination'], 'string', 'max' => 80],
            ['destination', 'compare', 'compareAttribute' => 'origin', 'operator' => '!=', 'message' => 'Destination must differ from origin.'],
            ['distance_km', 'number', 'min' => 1],
            ['base_fare', 'number', 'min' => 0],
        ];
    }

    public function getLabel() { return $this->origin . ' → ' . $this->destination; }

    public function formFields()
    {
        return [
            'origin' => ['type' => 'text'],
            'destination' => ['type' => 'text'],
            'distance_km' => ['type' => 'number'],
            'base_fare' => ['type' => 'number'],
        ];
    }

    public function listColumns()
    {
        return [
            'id', 'origin', 'destination', 'distance_km',
            ['attribute' => 'base_fare', 'value' => function ($m) { return number_format($m->base_fare); }],
        ];
    }

    public function searchAttributes() { return ['origin', 'destination']; }
}
