<?php
namespace app\models;

use yii\helpers\ArrayHelper;

class Trip extends BaseModel
{
    public static function tableName() { return 'trip'; }

    public static function statusOptions() { return self::opts(['Scheduled', 'Ongoing', 'Completed', 'Cancelled']); }

    public function rules()
    {
        return [
            [['route_id', 'vehicle_id', 'driver_id', 'departure_time', 'fare', 'status'], 'required'],
            [['route_id', 'vehicle_id', 'driver_id'], 'integer'],
            [['route_id'], 'exist', 'targetClass' => Route::class, 'targetAttribute' => 'id'],
            [['vehicle_id'], 'exist', 'targetClass' => Vehicle::class, 'targetAttribute' => 'id'],
            [['driver_id'], 'exist', 'targetClass' => Driver::class, 'targetAttribute' => 'id'],
            ['fare', 'number', 'min' => 0],
            [['departure_time', 'arrival_time'], 'date', 'format' => 'php:Y-m-d H:i:s'],
            ['arrival_time', 'default', 'value' => null],
            ['status', 'in', 'range' => array_keys(self::statusOptions())],
        ];
    }

    public function beforeValidate()
    {
        // Convert HTML datetime-local values (2026-11-01T08:00) to MySQL format
        foreach (['departure_time', 'arrival_time'] as $a) {
            $v = trim((string)$this->$a);
            if ($v === '') { $this->$a = null; continue; }
            $v = str_replace('T', ' ', $v);
            if (strlen($v) === 16) { $v .= ':00'; }
            $this->$a = $v;
        }
        return parent::beforeValidate();
    }

    public function getRoute() { return $this->hasOne(Route::class, ['id' => 'route_id']); }
    public function getVehicle() { return $this->hasOne(Vehicle::class, ['id' => 'vehicle_id']); }
    public function getDriver() { return $this->hasOne(Driver::class, ['id' => 'driver_id']); }
    public function getPayments() { return $this->hasMany(Payment::class, ['trip_id' => 'id']); }

    public function getSeatsBooked()
    {
        return (int)Payment::find()->where(['trip_id' => $this->id, 'status' => 'Paid'])->sum('seats');
    }

    public function getSeatsAvailable()
    {
        return max(0, $this->vehicle->capacity - $this->seatsBooked);
    }

    public function formFields()
    {
        return [
            'route_id' => ['type' => 'dropdown', 'items' => ArrayHelper::map(Route::find()->all(), 'id', 'label')],
            'vehicle_id' => ['type' => 'dropdown', 'items' => ArrayHelper::map(
                Vehicle::find()->where(['<>', 'status', 'Maintenance'])->all(), 'id',
                function ($v) { return $v->plate_number . ' (' . $v->type . ', ' . $v->capacity . ' seats)'; })],
            'driver_id' => ['type' => 'dropdown', 'items' => ArrayHelper::map(
                Driver::find()->where(['status' => 'Active'])->all(), 'id', 'full_name')],
            'departure_time' => ['type' => 'datetime'],
            'arrival_time' => ['type' => 'datetime'],
            'fare' => ['type' => 'number'],
            'status' => ['type' => 'dropdown', 'items' => self::statusOptions()],
        ];
    }

    public function listColumns()
    {
        return [
            'id',
            ['label' => 'Route', 'value' => function ($m) { return $m->route->label; }],
            ['label' => 'Vehicle', 'value' => function ($m) { return $m->vehicle->plate_number; }],
            ['label' => 'Driver', 'value' => function ($m) { return $m->driver->full_name; }],
            'departure_time',
            ['attribute' => 'fare', 'value' => function ($m) { return number_format($m->fare); }],
            ['label' => 'Seats left', 'value' => function ($m) { return $m->seatsAvailable; }],
            'status',
        ];
    }

    public function searchAttributes() { return ['departure_time']; }
}
