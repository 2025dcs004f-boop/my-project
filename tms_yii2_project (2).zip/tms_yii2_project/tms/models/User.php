<?php
namespace app\models;

use Yii;
use yii\db\ActiveRecord;
use yii\web\IdentityInterface;

class User extends ActiveRecord implements IdentityInterface
{
    const ROLE_ADMIN = 'admin';
    const ROLE_PASSENGER = 'passenger';
    const ROLE_DRIVER = 'driver';

    public static function tableName()
    {
        return 'user';
    }

    public function rules()
    {
        return [
            [['full_name', 'username', 'email'], 'required'],
            [['username', 'email'], 'unique'],
            ['email', 'email'],
            ['phone', 'string', 'max' => 20],
            ['role', 'in', 'range' => [self::ROLE_ADMIN, self::ROLE_PASSENGER, self::ROLE_DRIVER]],
        ];
    }

    public function beforeSave($insert)
    {
        if ($insert && !$this->auth_key) {
            $this->auth_key = Yii::$app->security->generateRandomString(32);
        }
        return parent::beforeSave($insert);
    }

    public static function findIdentity($id) { return static::findOne($id); }
    public static function findIdentityByAccessToken($token, $type = null) { return null; }
    public function getId() { return $this->id; }
    public function getAuthKey() { return $this->auth_key; }
    public function validateAuthKey($authKey) { return $this->auth_key === $authKey; }

    public function validatePassword($password)
    {
        return Yii::$app->security->validatePassword($password, $this->password_hash);
    }

    public function setPassword($password)
    {
        $this->password_hash = Yii::$app->security->generatePasswordHash($password);
    }

    public function getDriver()
    {
        return $this->hasOne(Driver::class, ['user_id' => 'id']);
    }

    public function isAdmin()
    {
        return $this->role === self::ROLE_ADMIN;
    }
}
