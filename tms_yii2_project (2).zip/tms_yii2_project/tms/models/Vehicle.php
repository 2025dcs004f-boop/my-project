<?php
namespace app\models;

class Vehicle extends BaseModel
{
    public static function tableName() { return 'vehicle'; }

    public static function statusOptions() { return self::opts(['Available', 'On Trip', 'Maintenance']); }

    public function rules()
    {
        return [
            [['plate_number', 'type', 'capacity', 'status'], 'required'],
            ['plate_number', 'unique'],
            ['plate_number', 'string', 'max' => 15],
            ['plate_number', 'filter', 'filter' => 'strtoupper'],
            ['capacity', 'integer', 'min' => 1, 'max' => 100],
            [['make_model'], 'string', 'max' => 100],
            ['type', 'in', 'range' => array_keys(self::opts(['Bus', 'Minibus', 'Taxi', 'Truck', 'Pickup']))],
            ['status', 'in', 'range' => array_keys(self::statusOptions())],
        ];
    }

    public function formFields()
    {
        return [
            'plate_number' => ['type' => 'text'],
            'type' => ['type' => 'dropdown', 'items' => self::opts(['Bus', 'Minibus', 'Taxi', 'Truck', 'Pickup'])],
            'make_model' => ['type' => 'text'],
            'capacity' => ['type' => 'number'],
            'status' => ['type' => 'dropdown', 'items' => self::statusOptions()],
        ];
    }

    public function listColumns()
{
    return [
        'id',
        ['attribute' => 'plate_number', 'format' => 'raw', 'value' => function ($m) {
            return '<i class="bi bi-bus-front text-primary me-1"></i> ' . \yii\helpers\Html::encode($m->plate_number);
        }],
        'type',
        'make_model',
        'capacity',
        ['attribute' => 'status', 'format' => 'raw', 'value' => function ($m) {
            $c = $m->status === 'Available' ? 'success' : ($m->status === 'Maintenance' ? 'warning text-dark' : 'secondary');
            return '<span class="badge rounded-pill bg-' . $c . '">' . \yii\helpers\Html::encode($m->status) . '</span>';
        }],
    ];
}


    public function searchAttributes() { return ['plate_number', 'make_model', 'type']; }
}
