<?php
use yii\helpers\Html;
/** @var $pending app\models\User[] */
/** @var $approved app\models\User[] */
$this->title = 'Account Approvals';
?>
<h3 class="mb-3">Account Approvals</h3>

<div class="card stat-card mb-4"><div class="card-body">
    <h5>Waiting for approval <span class="badge bg-warning text-dark"><?= count($pending) ?></span></h5>
    <div class="table-responsive"><table class="table align-middle">
        <thead><tr><th>Name</th><th>Username</th><th>Email</th><th>Phone</th><th>Type</th><th>Registered</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($pending as $u): ?>
            <tr>
                <td><?= Html::encode($u->full_name) ?></td>
                <td><?= Html::encode($u->username) ?></td>
                <td><?= Html::encode($u->email) ?></td>
                <td><?= Html::encode($u->phone) ?></td>
                <td><span class="badge bg-secondary"><?= Html::encode($u->role) ?></span></td>
                <td><?= Html::encode($u->created_at) ?></td>
                <td class="text-nowrap">
                    <?= Html::a('Approve', ['approve', 'id' => $u->id], ['class' => 'btn btn-sm btn-success', 'data' => ['method' => 'post']]) ?>
                    <?= Html::a('Reject', ['reject', 'id' => $u->id], ['class' => 'btn btn-sm btn-outline-danger',
                        'data' => ['method' => 'post', 'confirm' => 'Reject and remove this account?']]) ?>
                </td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$pending): ?><tr><td colspan="7" class="text-muted">No accounts are waiting for approval.</td></tr><?php endif; ?>
        </tbody>
    </table></div>
</div></div>

<div class="card stat-card"><div class="card-body">
    <h5>Recently approved</h5>
    <div class="table-responsive"><table class="table align-middle">
        <thead><tr><th>Name</th><th>Username</th><th>Email</th><th>Type</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($approved as $u): ?>
            <tr>
                <td><?= Html::encode($u->full_name) ?></td>
                <td><?= Html::encode($u->username) ?></td>
                <td><?= Html::encode($u->email) ?></td>
                <td><span class="badge bg-secondary"><?= Html::encode($u->role) ?></span></td>
                <td><?= Html::a('Suspend', ['suspend', 'id' => $u->id], ['class' => 'btn btn-sm btn-outline-warning',
                    'data' => ['method' => 'post', 'confirm' => 'Put this account back to waiting for approval?']]) ?></td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$approved): ?><tr><td colspan="5" class="text-muted">No approved accounts yet.</td></tr><?php endif; ?>
        </tbody>
    </table></div>
</div></div>
