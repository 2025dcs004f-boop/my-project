<?php
use yii\helpers\Html;
/** @var $p app\models\DriverPayment */
$this->title = 'Payslip ' . $p->reference;
$d = $p->driver;
?>
<div class="row justify-content-center"><div class="col-md-7"><div class="card stat-card"><div class="card-body p-4">
    <div class="text-center mb-3"><h4 class="mb-0">Transport Management System</h4><div class="text-muted">Driver Payment Slip</div></div>
    <table class="table table-sm">
        <tr><th>Slip No.</th><td><?= Html::encode($p->reference) ?></td></tr>
        <tr><th>Driver</th><td><?= Html::encode($d->full_name) ?></td></tr>
        <tr><th>Licence No.</th><td><?= Html::encode($d->license_number) ?></td></tr>
        <tr><th>For month</th><td><?= Html::encode(date('F Y', strtotime($p->period_month . '-01'))) ?></td></tr>
        <tr><th>Payment type</th><td><?= Html::encode($p->type) ?></td></tr>
        <tr><th>Method</th><td><?= Html::encode($p->method) ?></td></tr>
        <tr><th>Amount paid</th><td><strong>UGX <?= number_format($p->amount) ?></strong></td></tr>
        <?php if ($p->note): ?><tr><th>Note</th><td><?= Html::encode($p->note) ?></td></tr><?php endif; ?>
        <tr><th>Date paid</th><td><?= Html::encode($p->paid_at) ?></td></tr>
        <tr><th>Status</th><td><span class="badge bg-success"><?= Html::encode($p->status) ?></span></td></tr>
    </table>
    <button class="btn btn-primary d-print-none" onclick="window.print()">🖨 Print payslip</button>
    <?= Html::a('Back', Yii::$app->user->identity->isAdmin() ? ['driver-payment/index'] : ['site/dashboard'], ['class' => 'btn btn-link d-print-none']) ?>
</div></div></div></div>
