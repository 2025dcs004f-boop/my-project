<?php
use yii\helpers\Html;
use yii\web\YiiAsset;

/** @var $this yii\web\View */
/** @var $content string */
YiiAsset::register($this);
$user = Yii::$app->user;
$isAdmin = !$user->isGuest && $user->identity->isAdmin();
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?= Html::csrfMetaTags() ?>
    <title><?= Html::encode($this->title ?: Yii::$app->name) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?= Yii::getAlias('@web/css/site.css') ?>" rel="stylesheet">
    <?php $this->head() ?>
</head>
<body>
<?php $this->beginBody() ?>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container">
    <?= Html::a('🚌 TMS', ['/site/index'], ['class' => 'navbar-brand']) ?>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav"><span class="navbar-toggler-icon"></span></button>
    <div class="collapse navbar-collapse" id="nav">
      <ul class="navbar-nav me-auto">
        <?php if (!$user->isGuest): ?>
          <li class="nav-item"><?= Html::a('Dashboard', ['/site/dashboard'], ['class' => 'nav-link']) ?></li>
        <?php endif; ?>
        <li class="nav-item"><?= Html::a('Trips', ['/site/trips'], ['class' => 'nav-link']) ?></li>
        <?php if ($isAdmin): ?>
           <li class="nav-item"><?= Html::a('Members', ['/member/index'], ['class' => 'nav-link']) ?></li>
           <li class="nav-item"><?= Html::a('approvals', ['/approval/index'], ['class' => 'nav lik']) ?></li>
          <li class="nav-item"><?= Html::a('Vehicles', ['/vehicle/index'], ['class' => 'nav-link']) ?></li>
          <li class="nav-item"><?= Html::a('Drivers', ['/driver/index'], ['class' => 'nav-link']) ?></li>
          <li class="nav-item"><?= Html::a('Routes', ['/route/index'], ['class' => 'nav-link']) ?></li>
          <li class="nav-item"><?= Html::a('Manage Trips', ['/trip/index'], ['class' => 'nav-link']) ?></li>
          <li class="nav-item"><?= Html::a('Payments', ['/payment/index'], ['class' => 'nav-link']) ?></li>
          <li class="nav-item"><?= Html::a('driver payments',['/driver-payment/index'], ['class' => 'nav-link']) ?></li>
          <li class="nav-item"><?= Html::a('Monthly Report', ['/report/monthly'], ['class' => 'nav-link']) ?></li>
        <?php elseif (!$user->isGuest): ?>
          <li class="nav-item"><?= Html::a('My Payments', ['/payment/my'], ['class' => 'nav-link']) ?></li>
        <?php endif; ?>
      </ul>
      <div class="d-flex align-items-center gap-2">
        <?php if ($user->isGuest): ?>
          <?= Html::a('Login', ['/site/login'], ['class' => 'btn btn-outline-light btn-sm']) ?>
          <?= Html::a('Register', ['/site/register'], ['class' => 'btn btn-primary btn-sm']) ?>
        <?php else: ?>
          <span class="text-white-50 small"><?= Html::encode($user->identity->full_name) ?> (<?= Html::encode($user->identity->role) ?>)</span>
          <?= Html::beginForm(['/site/logout'], 'post') ?>
          <?= Html::submitButton('Logout', ['class' => 'btn btn-outline-light btn-sm']) ?>
          <?= Html::endForm() ?>
        <?php endif; ?>
      </div>
    </div>
  </div>
</nav>
<main class="container py-4">
    <?php foreach (Yii::$app->session->getAllFlashes() as $type => $msg): ?>
        <div class="alert alert-<?= Html::encode($type) ?> d-print-none"><?= Html::encode($msg) ?></div>
    <?php endforeach; ?>
    <?php if (!Yii::$app->user->isGuest && !Yii::$app->user->identity->isAdmin() && !Yii::$app->user->identity->approved): ?>
  <div class="alert alert-warning d-print-none">Your account is waiting for admin approval. You can browse trips, but you can't book or pay yet.</div>
<?php endif; ?>

    <?= $content ?>
</main>
<footer class="text-center text-muted small py-3 d-print-none">&copy; <?= date('Y') ?> Transport Management System &middot; USJM Diploma in Computer Science &middot; Yii 2</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<?php $this->endBody() ?>
</body>
</html>
<?php $this->endPage() ?>
