<?php
use yii\helpers\Html;
use yii\grid\GridView;
$cols = [
    'reference',
    ['label' => 'Route', 'value' => function ($m) { return $m->trip->route->label; }],
    'seats',
    ['attribute' => 'amount', 'value' => function ($m) { return number_format($m->amount); }],
    'method', 'status', 'paid_at',
    ['format' => 'raw', 'value' => function ($m) { return Html::a('Receipt', ['payment/receipt', 'id' => $m->id], ['class' => 'btn btn-sm btn-outline-primary']); }],
];
if (!empty($admin)) {
    array_splice($cols, 1, 0, [
        ['label' => 'Passenger name', 'value' => function ($m) { return $m->user->full_name; }],
        ['label' => 'Phone', 'value' => function ($m) { return $m->user->phone; }],
    ]);
}
echo GridView::widget([
    'dataProvider' => $dataProvider,
    'tableOptions' => ['class' => 'table table-striped align-middle'],
    'layout' => "{items}\n{summary}\n{pager}",
    'pager' => ['linkContainerOptions' => ['class' => 'page-item'], 'linkOptions' => ['class' => 'page-link'],
        'disabledListItemSubTagOptions' => ['class' => 'page-link'], 'options' => ['class' => 'pagination']],
    'columns' => $cols,
]);
