<?php
use yii\helpers\Html;
$this->title = 'All Payments';
?>
<h3 class="mb-3">All Payments</h3>
<form method="get" class="row g-2 mb-3">
    <input type="hidden" name="r" value="payment/index">
    <div class="col-md-5"><input type="text" name="q" value="<?= Html::encode($q) ?>" class="form-control" placeholder="Search reference, passenger or method"></div>
    <div class="col-auto"><button class="btn btn-outline-secondary">Search</button> <?= Html::a('Reset', ['index'], ['class' => 'btn btn-link']) ?></div>
</form>
<div class="card stat-card"><div class="card-body"><?= $this->render('_grid', ['dataProvider' => $dataProvider, 'admin' => true]) ?></div></div>
