<?php
$this->title = 'My Payments';
?>
<h3 class="mb-3">My Payments</h3>
<div class="card stat-card"><div class="card-body"><?= $this->render('_grid', ['dataProvider' => $dataProvider]) ?></div></div>
