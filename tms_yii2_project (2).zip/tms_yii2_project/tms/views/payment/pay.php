<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;
/** @var $model app\models\Payment */
/** @var $trip app\models\Trip */
$this->title = 'Payment';
$fare = (float)$trip->fare;
$this->registerJs("
function upd(){ var s=parseInt($('#payment-seats').val())||0; $('#total').text((s*$fare).toLocaleString()); }
$('#payment-seats').on('input',upd); upd();
function tog(){ $('.phone-box').toggle($('#payment-method').val()==='Mobile Money'); }
$('#payment-method').on('change',tog); tog();
");
?>
<div class="row justify-content-center"><div class="col-md-7"><div class="card stat-card"><div class="card-body p-4">
<h3 class="mb-3">Book &amp; Pay</h3>
<div class="alert alert-light border">
    <strong><?= Html::encode($trip->route->label) ?></strong><br>
    Departs: <?= Html::encode($trip->departure_time) ?> &middot; Vehicle: <?= Html::encode($trip->vehicle->plate_number) ?><br>
    Fare: UGX <?= number_format($trip->fare) ?> per seat &middot; Seats left: <?= $trip->seatsAvailable ?>
</div>
<?php $form = ActiveForm::begin(); ?>
    <?= $form->field($model, 'seats')->input('number', ['min' => 1, 'max' => max(1, $trip->seatsAvailable)]) ?>
    <?= $form->field($model, 'method')->dropDownList(\app\models\Payment::methods(), ['class' => 'form-select']) ?>
    <div class="phone-box"><?= $form->field($model, 'payer_phone')->textInput(['placeholder' => 'Mobile Money number']) ?></div>
    <h5>Total: UGX <span id="total">0</span></h5>
    <?= Html::submitButton('Pay now', ['class' => 'btn btn-success']) ?>
    <?= Html::a('Cancel', ['site/trips'], ['class' => 'btn btn-link']) ?>
<?php ActiveForm::end(); ?>
<p class="text-muted small mt-3 mb-0">Note: payment is simulated for this prototype; a real gateway can be added later.</p>
</div></div></div></div>
