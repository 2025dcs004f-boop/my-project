<?php
use yii\helpers\Html;
/** @var $payment app\models\Payment */
$this->title = 'Receipt ' . $payment->reference;
$t = $payment->trip;
?>
<div class="row justify-content-center"><div class="col-md-7"><div class="card stat-card"><div class="card-body p-4">
    <div class="text-center mb-3"><h4 class="mb-0">Transport Management System</h4><div class="text-muted">Payment Receipt</div></div>
    <table class="table table-sm">
        <tr><th>Receipt No.</th><td><?= Html::encode($payment->reference) ?></td></tr>
        <tr><th>Passenger</th><td><?= Html::encode($payment->user->full_name) ?></td></tr>
        <tr><th>Phone</th><td><?= Html::encode($payment->user->phone) ?></td></tr>
        <tr><th>Route</th><td><?= Html::encode($t->route->label) ?></td></tr>
        <tr><th>Departure</th><td><?= Html::encode($t->departure_time) ?></td></tr>
        <tr><th>Vehicle</th><td><?= Html::encode($t->vehicle->plate_number) ?></td></tr>
        <tr><th>Seats</th><td><?= (int)$payment->seats ?></td></tr>
        <tr><th>Method</th><td><?= Html::encode($payment->method) ?></td></tr>
        <tr><th>Amount paid</th><td><strong>UGX <?= number_format($payment->amount) ?></strong></td></tr>
        <tr><th>Date</th><td><?= Html::encode($payment->paid_at) ?></td></tr>
        <tr><th>Status</th><td><span class="badge bg-success"><?= Html::encode($payment->status) ?></span></td></tr>
    </table>
    <button class="btn btn-primary d-print-none" onclick="window.print()">🖨 Print receipt</button>
    <?= Html::a('Back', ['payment/my'], ['class' => 'btn btn-link d-print-none']) ?>
</div></div></div></div>
