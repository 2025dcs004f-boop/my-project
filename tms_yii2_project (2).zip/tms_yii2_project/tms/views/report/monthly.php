<?php
use yii\helpers\Html;
/** @var $month string */
$this->title = 'Monthly Report';
$label = date('F Y', strtotime($month . '-01'));
?>
<div class="d-flex justify-content-between align-items-end mb-3 d-print-none">
    <form method="get" class="d-flex gap-2 align-items-end">
        <input type="hidden" name="r" value="report/monthly">
        <div><label class="form-label mb-0">Select month</label><input type="month" name="month" value="<?= Html::encode($month) ?>" class="form-control"></div>
        <button class="btn btn-primary">Generate</button>
    </form>
    <button class="btn btn-success" onclick="window.print()">🖨 Print / Save as PDF</button>
</div>

<div class="card stat-card mb-3"><div class="card-body">
    <div class="text-center mb-4">
        <h3 class="mb-0">Transport Management System</h3>
        <h5 class="text-muted">Monthly Report — <?= Html::encode($label) ?></h5>
        <small>Generated on <?= date('d M Y H:i') ?> by <?= Html::encode(Yii::$app->user->identity->full_name) ?></small>
    </div>

    <div class="row text-center mb-4 g-2">
        <div class="col"><div class="fs-4 fw-bold"><?= (int)$summary['payments'] ?></div>Bookings</div>
        <div class="col"><div class="fs-4 fw-bold"><?= (int)$summary['seats'] ?></div>Seats sold</div>
        <div class="col"><div class="fs-4 fw-bold"><?= array_sum(array_column($tripStatus, 'total')) ?></div>Trips</div>
        <div class="col"><div class="fs-4 fw-bold">UGX <?= number_format($summary['revenue']) ?></div>Ticket revenue</div>
        <div class="col"><div class="fs-4 fw-bold text-danger">UGX <?= number_format($driverTotal) ?></div>Driver payments</div>
        <div class="col"><div class="fs-4 fw-bold <?= $net < 0 ? 'text-danger' : 'text-success' ?>">UGX <?= number_format($net) ?></div>Net income</div>
    </div>

    <h5>Trips by status</h5>
    <table class="table table-sm table-bordered w-auto mb-4"><tr><th>Status</th><th>Trips</th></tr>
    <?php foreach ($tripStatus as $r): ?><tr><td><?= Html::encode($r['status']) ?></td><td><?= $r['total'] ?></td></tr><?php endforeach; ?>
    <?php if (!$tripStatus): ?><tr><td colspan="2" class="text-muted">No trips this month.</td></tr><?php endif; ?></table>

    <h5>Revenue by route</h5>
    <table class="table table-sm table-bordered mb-4"><thead><tr><th>Route</th><th>Trips</th><th>Seats</th><th class="text-end">Revenue (UGX)</th></tr></thead><tbody>
    <?php foreach ($byRoute as $r): ?><tr><td><?= Html::encode($r['origin'] . ' → ' . $r['destination']) ?></td><td><?= $r['trips'] ?></td><td><?= $r['seats'] ?></td><td class="text-end"><?= number_format($r['revenue']) ?></td></tr><?php endforeach; ?>
    <?php if (!$byRoute): ?><tr><td colspan="4" class="text-muted">No revenue this month.</td></tr><?php endif; ?></tbody></table>

    <div class="row">
        <div class="col-md-6"><h5>Trips per vehicle</h5>
            <table class="table table-sm table-bordered"><thead><tr><th>Plate</th><th>Type</th><th>Trips</th></tr></thead><tbody>
            <?php foreach ($byVehicle as $r): ?><tr><td><?= Html::encode($r['plate_number']) ?></td><td><?= Html::encode($r['type']) ?></td><td><?= $r['trips'] ?></td></tr><?php endforeach; ?>
            <?php if (!$byVehicle): ?><tr><td colspan="3" class="text-muted">None</td></tr><?php endif; ?></tbody></table></div>
        <div class="col-md-6"><h5>Trips per driver</h5>
            <table class="table table-sm table-bordered"><thead><tr><th>Driver</th><th>Licence</th><th>Trips</th><th class="text-end">Paid (UGX)</th></tr></thead><tbody>
            <?php foreach ($byDriver as $r): ?><tr><td><?= Html::encode($r['full_name']) ?></td><td><?= Html::encode($r['license_number']) ?></td><td><?= $r['trips'] ?></td><td class="text-end"><?= number_format($paidBy[$r['id']] ?? 0) ?></td></tr><?php endforeach; ?>
            <?php if (!$byDriver): ?><tr><td colspan="4" class="text-muted">None</td></tr><?php endif; ?></tbody></table></div>
    </div>

    <h5>Driver payments (<?= Html::encode($label) ?>)</h5>
    <table class="table table-sm table-bordered mb-4"><thead><tr><th>Date paid</th><th>Ref</th><th>Driver</th><th>Type</th><th>Method</th><th class="text-end">Amount</th></tr></thead><tbody>
    <?php foreach ($driverPays as $d): ?><tr><td><?= Html::encode($d->paid_at) ?></td><td><?= Html::encode($d->reference) ?></td><td><?= Html::encode($d->driver->full_name) ?></td><td><?= Html::encode($d->type) ?></td><td><?= Html::encode($d->method) ?></td><td class="text-end"><?= number_format($d->amount) ?></td></tr><?php endforeach; ?>
    <?php if (!$driverPays): ?><tr><td colspan="6" class="text-muted">No driver payments recorded for this month.</td></tr><?php endif; ?>
    <tr class="fw-bold"><td colspan="5" class="text-end">TOTAL DRIVER PAYMENTS</td><td class="text-end"><?= number_format($driverTotal) ?></td></tr></tbody></table>

    <h5>Passenger payment details</h5>
    <table class="table table-sm table-bordered"><thead><tr><th>Date</th><th>Ref</th><th>Passenger</th><th>Route</th><th>Seats</th><th>Method</th><th class="text-end">Amount</th></tr></thead><tbody>
    <?php foreach ($payments as $p): ?><tr><td><?= Html::encode($p->paid_at) ?></td><td><?= Html::encode($p->reference) ?></td><td><?= Html::encode($p->user->full_name) ?></td><td><?= Html::encode($p->trip->route->label) ?></td><td><?= $p->seats ?></td><td><?= Html::encode($p->method) ?></td><td class="text-end"><?= number_format($p->amount) ?></td></tr><?php endforeach; ?>
    <?php if (!$payments): ?><tr><td colspan="7" class="text-muted">No payments this month.</td></tr><?php endif; ?>
    <tr class="fw-bold"><td colspan="6" class="text-end">TOTAL TICKET REVENUE</td><td class="text-end"><?= number_format($summary['revenue']) ?></td></tr></tbody></table>
    <h5 class="text-end">Net income = UGX <?= number_format($summary['revenue']) ?> − UGX <?= number_format($driverTotal) ?> = <strong>UGX <?= number_format($net) ?></strong></h5>
</div></div>
