<?php
use yii\helpers\Html;
$this->title = 'Admin Dashboard';
$cards = [
    ['Vehicles', $vehicles, 'vehicle/index', 'primary'], ['Drivers', $drivers, 'driver/index', 'success'],
    ['Routes', $routes, 'route/index', 'warning'], ['Trips', $trips, 'trip/index', 'info'],
    ['Members', $passengers, 'member/index', 'secondary'],
];
?>
<h3 class="mb-3">Admin Dashboard</h3>
<div class="row g-3 mb-4">
<?php foreach ($cards as $c): ?>
  <div class="col-6 col-md-4 col-lg"><a href="<?= \yii\helpers\Url::to([$c[2]]) ?>" class="text-decoration-none"><div class="card stat-card text-center p-3 border-start border-4 border-<?= $c[3] ?>">
    <div class="num"><?= $c[1] ?></div><div class="text-muted"><?= $c[0] ?></div></div></a></div>
<?php endforeach; ?>
</div>
<div class="card stat-card mb-4"><div class="card-body d-flex justify-content-between align-items-center">
    <div><div class="text-muted">Revenue this month</div><div class="num">UGX <?= number_format($revenue) ?></div></div>
    <div class="d-flex gap-2"><?= Html::a('Pay a driver', ['driver-payment/create'], ['class' => 'btn btn-outline-primary']) ?>
    <?= Html::a('Open Monthly Report', ['report/monthly'], ['class' => 'btn btn-primary']) ?></div>
</div></div>
<div class="card stat-card"><div class="card-body">
    <h5>Recent payments</h5>
    <table class="table table-sm"><thead><tr><th>Ref</th><th>Passenger</th><th>Route</th><th>Amount</th><th>Date</th></tr></thead><tbody>
    <?php foreach ($recent as $p): ?>
        <tr><td><?= Html::encode($p->reference) ?></td><td><?= Html::encode($p->user->full_name) ?></td>
        <td><?= Html::encode($p->trip->route->label) ?></td><td><?= number_format($p->amount) ?></td><td><?= $p->paid_at ?></td></tr>
    <?php endforeach; ?>
    <?php if (!$recent): ?><tr><td colspan="5" class="text-muted">No payments yet.</td></tr><?php endif; ?>
    </tbody></table>
</div></div>
