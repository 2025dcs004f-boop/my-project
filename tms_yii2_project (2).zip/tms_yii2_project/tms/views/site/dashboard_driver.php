<?php
use yii\helpers\Html;
/** @var $driver app\models\Driver|null */
$this->title = 'Driver Dashboard';
?>
<h3 class="mb-3">Welcome, <?= Html::encode(Yii::$app->user->identity->full_name) ?></h3>
<?php if (!$driver): ?>
    <div class="alert alert-warning">Your driver profile is not linked yet. Please contact the administrator.</div>
<?php else:
    $daysLeft = (strtotime($driver->license_expiry) - time()) / 86400; ?>
    <?php if ($daysLeft < 0): ?><div class="alert alert-danger">Your driving licence has expired. Please renew it.</div>
    <?php elseif ($daysLeft < 30): ?><div class="alert alert-warning">Your driving licence expires in <?= (int)$daysLeft ?> day(s).</div><?php endif; ?>
    <div class="row g-3 mb-4">
        <div class="col-6 col-md-3"><div class="card stat-card p-3 text-center"><div class="text-muted">Licence No.</div><b><?= Html::encode($driver->license_number) ?></b></div></div>
        <div class="col-6 col-md-3"><div class="card stat-card p-3 text-center"><div class="text-muted">Expires</div><b><?= Html::encode($driver->license_expiry) ?></b></div></div>
        <div class="col-6 col-md-3"><div class="card stat-card p-3 text-center"><div class="text-muted">Status</div><b><?= Html::encode($driver->status) ?></b></div></div>
        <div class="col-6 col-md-3"><div class="card stat-card p-3 text-center"><div class="text-muted">Total received</div><b>UGX <?= number_format($total) ?></b></div></div>
    </div>
    <div class="card stat-card mb-4"><div class="card-body"><h5>My trips</h5>
        <table class="table table-sm"><thead><tr><th>Route</th><th>Vehicle</th><th>Departure</th><th>Status</th></tr></thead><tbody>
        <?php foreach ($trips as $t): ?><tr><td><?= Html::encode($t->route->label) ?></td><td><?= Html::encode($t->vehicle->plate_number) ?></td><td><?= Html::encode($t->departure_time) ?></td><td><?= Html::encode($t->status) ?></td></tr><?php endforeach; ?>
        <?php if (!$trips): ?><tr><td colspan="4" class="text-muted">No trips assigned yet.</td></tr><?php endif; ?></tbody></table></div></div>
    <div class="card stat-card"><div class="card-body"><h5>My payments</h5>
        <table class="table table-sm"><thead><tr><th>Month</th><th>Type</th><th>Method</th><th>Reference</th><th class="text-end">Amount</th><th></th></tr></thead><tbody>
        <?php foreach ($pays as $p): ?><tr><td><?= Html::encode($p->period_month) ?></td><td><?= Html::encode($p->type) ?></td><td><?= Html::encode($p->method) ?></td><td><?= Html::encode($p->reference) ?></td><td class="text-end"><?= number_format($p->amount) ?></td>
        <td><?= Html::a('Payslip', ['driver-payment/payslip', 'id' => $p->id], ['class' => 'btn btn-sm btn-outline-primary']) ?></td></tr><?php endforeach; ?>
        <?php if (!$pays): ?><tr><td colspan="6" class="text-muted">No payments yet.</td></tr><?php endif; ?></tbody></table></div></div>
<?php endif; ?>
