<?php
use yii\helpers\Html;
$this->title = 'My Dashboard';
?>
<h3 class="mb-3">Welcome, <?= Html::encode(Yii::$app->user->identity->full_name) ?></h3>
<div class="row g-3 mb-4">
  <div class="col-md-4"><div class="card stat-card text-center p-3"><div class="num"><?= count($trips) ?></div><div class="text-muted">Upcoming trips</div></div></div>
  <div class="col-md-4"><div class="card stat-card text-center p-3"><div class="num"><?= $myPayments ?></div><div class="text-muted">My payments</div>
     <?= Html::a('View', ['payment/my'], ['class' => 'btn btn-sm btn-outline-primary mt-2']) ?></div></div>
</div>
<?= Html::a('Browse &amp; book trips', ['site/trips'], ['class' => 'btn btn-primary', 'encode' => false]) ?>
