<?php
use yii\helpers\Html;
$this->title = $name;
?>
<div class="alert alert-danger"><h4><?= Html::encode($name) ?></h4><p><?= nl2br(Html::encode($message)) ?></p></div>
<?= Html::a('Back to home', ['site/index'], ['class' => 'btn btn-primary']) ?>
