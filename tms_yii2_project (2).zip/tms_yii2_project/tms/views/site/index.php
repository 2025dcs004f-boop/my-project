<?php
use yii\helpers\Html;
$this->title = 'Welcome';
$this->registerCssFile('https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css');
$bg = 'data:image/jpeg;base64,' . base64_encode(file_get_contents(Yii::getAlias('@webroot') . '/images/bus.jpg'));
?>
<div class="hero" style="background: linear-gradient(rgba(20,15,50,.3), rgba(20,15,50,.3)), url('<?= $bg ?>') center/cover no-repeat;">
    <h1 class="display-5 fw-bold">Transport Management System</h1>
    <p class="lead">Manage members, vehicles, drivers, routes and trips — and let passengers book and pay online.</p>
    <?= Html::a('Login', ['site/login'], ['class' => 'btn btn-light btn-lg me-2']) ?>
    <?= Html::a('Create Account', ['site/register'], ['class' => 'btn btn-outline-light btn-lg']) ?>
</div>
<div class="row g-3 feature-row">
  <div class="col-md-4"><div class="feature-card">
    <i class="bi bi-compass feature-icon"></i>
    <h5>Browse Trips</h5>
    <p>See upcoming scheduled trips and fares.</p>
    <a href="index.php?r=trip/index" class="btn btn-light">View trips</a>
  </div></div>
  <div class="col-md-4"><div class="feature-card">
    <i class="bi bi-cash-coin feature-icon"></i>
    <h5>Book &amp; Pay</h5>
    <p>Register, choose a trip and pay with Mobile Money, Card or Cash.</p>
    <a href="index.php?r=trip/index" class="btn btn-light">View trips</a>
  </div></div>
  <div class="col-md-4"><div class="feature-card">
    <i class="bi bi-graph-up-arrow feature-icon"></i>
    <h5>Admin Reports</h5>
    <p>Admins manage the fleet and print monthly reports.</p>
    <a href="index.php?r=trip/index" class="btn btn-light">View trips</a>
  </div></div>

<?php if (!Yii::$app->user->isGuest): ?>
<div class="col-md-4"><div class="feature-card">
  <i class="bi bi-people feature-icon"></i>
  <h5>Members</h5>
  <p>See registered members.</p>
  <a href="index.php?r=member/index" class="btn btn-light">View members</a>
</div></div>
</div>
<?php endif; ?>
