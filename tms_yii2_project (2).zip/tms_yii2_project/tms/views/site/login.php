<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;
$this->title = 'Login';
?>
<div class="row justify-content-center"><div class="col-md-5"><div class="card stat-card"><div class="card-body p-4">
    <h3 class="mb-3">Login</h3>
    <?php $form = ActiveForm::begin(['id' => 'login-form']); ?>
        <?= $form->field($model, 'username')->textInput(['autofocus' => true]) ?>
        <?= $form->field($model, 'password')->passwordInput() ?>
        <?= $form->field($model, 'rememberMe')->checkbox() ?>
        <?= Html::submitButton('Login', ['class' => 'btn btn-primary w-100']) ?>
    <?php ActiveForm::end(); ?>
    <p class="mt-3 mb-0 text-center">No account? <?= Html::a('Register', ['site/register']) ?></p>
</div></div></div></div>
