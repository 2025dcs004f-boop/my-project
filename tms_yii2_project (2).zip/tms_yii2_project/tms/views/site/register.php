<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;
$this->title = 'Register';
$this->registerJs("
function togDriver(){ $('.driver-fields').toggle($('#registerform-account_type').val()==='driver'); }
$('#registerform-account_type').on('change',togDriver); togDriver();
");
?>
<div class="row justify-content-center"><div class="col-md-7"><div class="card stat-card"><div class="card-body p-4">
    <h3 class="mb-3">Create account</h3>
    <?php $form = ActiveForm::begin(['id' => 'register-form']); ?>
        <?= $form->field($model, 'account_type')->dropDownList(['passenger' => 'Passenger', 'driver' => 'Driver'], ['class' => 'form-select']) ?>
        <?= $form->field($model, 'full_name') ?>
        <?= $form->field($model, 'username') ?>
        <?= $form->field($model, 'email') ?>
        <?= $form->field($model, 'phone')->textInput(['placeholder' => '0700123456']) ?>
        <div class="driver-fields" style="display:none">
            <div class="alert alert-info py-2 small">Driver details — the administrator will use these to assign you to trips and pay you.</div>
            <?= $form->field($model, 'license_number') ?>
            <?= $form->field($model, 'license_expiry')->input('date') ?>
        </div>
        <?= $form->field($model, 'password')->passwordInput() ?>
        <?= $form->field($model, 'password_repeat')->passwordInput() ?>
        <?= Html::submitButton('Register', ['class' => 'btn btn-primary w-100']) ?>
    <?php ActiveForm::end(); ?>
    <p class="mt-3 mb-0 text-center">Already registered? <?= Html::a('Login', ['site/login']) ?></p>
</div></div></div></div>
