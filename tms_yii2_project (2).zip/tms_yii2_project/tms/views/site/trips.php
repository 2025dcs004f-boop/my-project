<?php
use yii\helpers\Html;
/** @var $trips app\models\Trip[] */
$this->title = 'Upcoming Trips';
?>
<h3 class="mb-3">Upcoming Trips</h3>
<?php if (!$trips): ?><div class="alert alert-info"> upcoming trips are scheduled.</div><?php endif; ?>
<div class="row g-3">
<?php foreach ($trips as $t): $left = $t->seatsAvailable; ?>
  <div class="col-md-6 col-lg-4"><div class="card stat-card h-100"><div class="card-body">
    <h5><?= Html::encode($t->route->label) ?></h5>
    <p class="mb-1">🕒 <?= date('D, d M Y H:i', strtotime($t->departure_time)) ?></p>
    <p class="mb-1">🚌 <?= Html::encode($t->vehicle->plate_number . ' (' . $t->vehicle->type . ')') ?></p>
    <p class="mb-1">💺 <?= $left ?> seat(s) left</p>
    <p class="fw-bold">UGX <?= number_format($t->fare) ?> / seat</p>
        <?php
$u = Yii::$app->user->identity;
$canBook = Yii::$app->user->isGuest || $u->isAdmin() || $u->approved;
?>
<?php if ($left <= 0): ?>
    <span class="badge bg-danger">Fully booked</span>
<?php elseif (!$canBook): ?>
    <span class="badge bg-secondary">Awaiting approval</span>
<?php else: ?>
    <?= Html::a('Book &amp; Pay', ['payment/pay', 'trip_id' => $t->id], ['class' => 'btn btn-primary btn-sm']) ?>
    <?php endif; ?>
    </div></div></div>
    <?php endforeach; ?>
  </div>